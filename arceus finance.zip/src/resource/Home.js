import Dashboard from "./pages/Dashboard"

function HomePage(params) {
    return (
        "HOME PAGE"
    )
}

export default HomePage