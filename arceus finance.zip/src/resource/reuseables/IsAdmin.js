import { ArceusTokenContract } from "./ContractInitialized"
async function IsAdmin(params) {

    const Owner = await ArceusTokenContract.owner()
    const isOwner = String(window.address).toLowerCase() === String(Owner).toLowerCase()
    return isOwner

}
export default IsAdmin