import { formatEther, formatUnits, parseUnits } from 'ethers/lib/utils';
import { numberWithCommas } from './Numbers';
import ContractAddresses from '../constants/ContractAddresses'
import AbiFunctions from '../constants/ArceusAbiFunctions'
import { ethers, BigNumber } from 'ethers'


// const testnet = 'https://data-seed-prebsc-1-s1.binance.org:8545';
// const client = ethers.getDefaultProvider(testnet)
// const PanCakeRouterContract = new ethers.Contract(ContractAddresses.pancakeRouter, AbiFunctions, client)
async function FetchTokenPriceBUSD(amountTokens) {

    const { PanCakeRouterContract } = window
    const tokens = amountTokens === 0 ? 1e5 : amountTokens

    try {
        const amtO = await PanCakeRouterContract.getAmountsOut(Number(tokens), [ContractAddresses.arceus, ContractAddresses.WETH])
        let amountArcToBnb = formatEther(BigNumber.from(amtO[1]));
        const final = await PanCakeRouterContract.getAmountsOut(parseUnits(amountArcToBnb, 'ether'), [ContractAddresses.WETH, ContractAddresses.BUSD])
        return parseFloat(formatEther(final[1].toString())).toFixed(3)
    } catch (error) { }
}

async function FetchBNBPriceBUSD(amount) {
    const { PanCakeRouterContract } = window
    const tokens = amount === 0 ? 1e5 : amount
    const final = await PanCakeRouterContract.getAmountsOut(parseUnits(tokens, 'ether'), [ContractAddresses.WETH, ContractAddresses.BUSD])
    return parseFloat(formatEther(final[1].toString())).toFixed(3)
}

export { FetchTokenPriceBUSD, FetchBNBPriceBUSD }