import { useState, useEffect } from "react"

function CountDownTime(params) {

    const [days, setDays] = useState('00')
    const [hours, setHours] = useState('00')
    const [mins, setMins] = useState('00')
    const [secs, setSecs] = useState('00')
    // const { DateTo } = params

    useEffect(() => {
        setInterval(() => {
            const date = new Date().getTime()
            let counto = new Date().getTime()
            const deadline = counto - date

            setDays(days => days = Math.floor(deadline / (1000 * 60 * 60 * 24)))
            setHours(hours => hours = Math.floor((deadline % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)))
            setMins(mins => mins = Math.floor((deadline % (1000 * 60 * 60)) / (1000 * 60)))
            setSecs(secs => secs = Math.floor((deadline % (1000 * 60)) / 1000))
        }, 1000);
    })

    return ({ days: days, hours: hours, mins: mins, secs: secs })
}


function CountDownSeconds(seconds) {

    const Time = new Date(seconds * 1000).toISOString()
    const H = Time.slice(11, 13) //> 1 ? Time.slice(11, 13) + 'hrs ' : Time.slice(11, 13) === 0 ? '' : Time.slice(11, 13) + 'hr '
    const M = Time.slice(14, 16) //> 1 ? Time.slice(14, 16) + 'mins ' : Time.slice(14, 16) === 0 ? '' : Time.slice(14, 16) + 'min '
    const S = Time.slice(17, 19) //> 1 ? Time.slice(17, 19) + 'secs' : Time.slice(17, 19) === 0 ? '' : Time.slice(17, 19) + 'sec'
    // let Hours = Time.slice(11, 13) > 0 ? H : ''
    // let Minutes = Time.slice(14, 16) > 1 ? M : ''
    // let Seconds = Time.slice(17, 19) > 1 ? S : ''

    return ({ hours: H, minutes: M, seconds: S})
}

function getTime(numSecs) {
    return new Date(numSecs * 1000).toUTCString()
}

function getDayTimeGreeting() {
    const dayTime = new Date().toTimeString()
    const DT = dayTime.slice(0, 2)
    const greeting =
        DT >= 5 && DT < 12 ? "Good Morning"
            : DT >= 12 && DT < 18 ? "Good Afternoon"
                : DT >= 18 && DT !== 5 ? "Good Evening"
                    : 'Welcome'
    return greeting
}

function DaysLest(From, To) {
    const diffDays = (From, To) => Math.ceil(Math.abs(From - To) / (1000 * 60 * 60 * 24))
    return diffDays(new Date('2014-12-19'), new Date('2020-01-01'));   // 1839
}

function CountDownToDate({ presaleStart, presaleEnd }) {

    let Today = new Date().getTime()
    let start = new Date(presaleStart)
    let midEnd = new Date(presaleEnd)
    let diff = (start - Today) > 0 ? start - Today : (midEnd - Today) > 0 ? midEnd - Today : 0

    // math
    let days = Math.floor(diff / (1000 * 60 * 60 * 24));
    let hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    let minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    let seconds = Math.floor((diff % (1000 * 60)) / 1000);

    let IcoStarted = (start - Today) <= 0
    let PresaleEnded = (midEnd - Today) <= 0
    let isOn = diff <= 0
    let dateTo = ''

    dateTo = {
        days: days,
        hours: hours,
        minutes: minutes,
        seconds: seconds,
        ended: diff,
        isOn: isOn,
        PresaleEnded: PresaleEnded,
        IcoStarted: IcoStarted
    }

    return dateTo
}

function CountDownWithAnim(countFrom) {
    // Credit: Mateusz Rybczonec

    const WARNING_THRESHOLD = 750;
    const ALERT_THRESHOLD = 1500;

    const COLOR_CODES = {
        info: {
            color: "green"
        },
        warning: {
            color: "orange",
            threshold: WARNING_THRESHOLD
        },
        alert: {
            color: "red",
            threshold: ALERT_THRESHOLD
        }
    };

    const TIME_LIMIT = countFrom;
    let timePassed = 0;
    let timeLeft = TIME_LIMIT;
    let remainingPathColor = COLOR_CODES.info.color
    let TImel = formatTime(timeLeft)

    function startTimer() {

        timePassed += 1500 - TIME_LIMIT;
        timeLeft = TIME_LIMIT - 1;
        TImel = formatTime(timeLeft);

        const { alert, warning } = COLOR_CODES;

        if (timeLeft >= alert.threshold) {
            remainingPathColor = alert.color
        } else if (timeLeft <= warning.threshold && timeLeft >= 450) {
            remainingPathColor = warning.color
        }

        const timPer = (timePassed * 100 / 1500).toFixed(0)
        const per = `${(timPer / 100 * 283).toFixed(0)} 283`

        return <div className="base-timer">
            <svg className="base-timer__svg" viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
                <g className="base-timer__circle">
                    <circle className="base-timer__path-elapsed" cx="50" cy="50" r="45"></circle>
                    <path
                        strokeDasharray={per}
                        className={`base-timer__path-remaining ${remainingPathColor}`}
                        d="M 50, 50 m -45, 0 a 45,45 0 1,0 90,0 a 45,45 0 1,0 -90,0"
                    ></path>
                </g>
            </svg>
            <span id="base-timer-label" className="base-timer__label">
                {TImel}
            </span>
        </div>
    }


    function formatTime(time) {
        const minutes = Math.floor(time / 60);
        let seconds = time % 60;

        if (seconds < 10) {
            seconds = `0${seconds}`;
        }

        return `${minutes}:${seconds}`;
    }


    return startTimer()

}


export { CountDownTime, CountDownSeconds, DaysLest, getTime, getDayTimeGreeting, CountDownToDate, CountDownWithAnim }