import { useEffect } from "react"
import { GetIcon } from "../icons/ExportIcon"

function Modal({ params }) {

    const { show, toggle, type } = params

    // useEffect(() => {
    //     Array.from(document.querySelectorAll('.modal')).map(
    //         mod => window.addEventListener('mouseup', (e) => {
    //             if (e.target !== mod && mod.contains(e.target) === false) {
    //                 toggle()
    //             }
    //         })
    //     )
    // })

    if (show === true && type === 'dexsettings')
        return (
            <div className="modal-main">
                <modal className='modal'>
                    <h4 className="h4-headline flex-nowrap space-between">
                        <span>Settings</span>
                        <GetIcon icon={'close'} trigger={toggle} classname={''} />
                    </h4>

                    <div className=""></div>
                </modal>
            </div>
        )
}

export default Modal