import { ethers } from "ethers";
import ContractAddresses from "../constants/ContractAddresses";
import AbiFunctions from "../constants/ArceusAbiFunctions";

    const testnet = 'https://data-seed-prebsc-1-s1.binance.org:8545';
    window.chain = '0x61'
    const signerPkey = process.env.REACT_APP_SIGNER_PKEY
    const client = ethers.getDefaultProvider(testnet)
    const Signer = new ethers.Wallet(signerPkey, client)
    export const ArceusTokenContract = new ethers.Contract(ContractAddresses.arceus, AbiFunctions, Signer)
    export const PanCakeRouterContract = new ethers.Contract(ContractAddresses.pancakeRouter, AbiFunctions, client)
