import { GetIcon } from "../icons/ExportIcon"

function SocialLinks() {
    return (
        <div className="icons-wrapper ">
            {/* <h4 className="h4-headline">Stay Connected</h4> */}
            {/* <a className="social-link" href="//facebook.com/">
                <GetIcon icon={'facebook'} />
            </a>*/}
            <a className="social-link" href="//reddit.com/">
                <GetIcon icon={'reddit'} />
            </a> 
            <a className="social-link" href="//twitter.com/">
                <GetIcon icon={'twitter'} />
            </a>
            <a className="social-link" href="//discord.com/">
                <GetIcon icon={'discord'} />
            </a>
            <a className="social-link" href="//telegram.me/">
                <GetIcon icon={'telegram'} />
            </a>
            {/* 
            <a className="social-link" href="//facebook.com/">
                <GetIcon icon={'subscription'} />
            </a> */}
        </div>
    )
}


export default SocialLinks