import { GetIcon } from "../icons/ExportIcon"

function NoData({params}) {

    const { login, isAuthenticated, isAuthenticating } = params

    return (
        <div className="no-data-wrap">
            <div className="no-data-inner">
                <h2 className="h2-headline">YOU ARE NOT LOGGEDIN</h2>
                <div className='t-price w-auto' onClick={!isAuthenticated && login}>
                    <GetIcon icon={isAuthenticated ? 'wallet' : isAuthenticating ? 'spinner' : 'login'} classname={isAuthenticating && 'spinner'} />
                    <span className='font-13'>Please Login</span>
                </div>
            </div>
        </div>
    )
}

export default NoData