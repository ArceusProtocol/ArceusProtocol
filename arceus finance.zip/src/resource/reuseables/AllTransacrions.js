// import { useEffect, useState } from 'react'
// import { CountDownSeconds, getTime } from "./CountDown"
// import { formatUnits } from 'ethers/lib/utils'

// function GetTransactionList() {

//     if (window.address) {

//         let endpount = `
//             https://api.bscscan.com/api
//             ?module=account
//             &action=txlistinternal
//             &address=${window.address}
//             &startblock=0
//             &endblock=99999999
//             &page=1
//             &offset=10
//             &sort=asc
//             &apikey=H6VF881M39SUR6UY92ZIBUKQ26QKFXIK7P`

//         endpount = endpount.replace(/\s/g, '')

//         fetch(endpount)
//             .then(response => response.json())
//             .then(data => { setTrans(data.result)})
//             .catch(error => console.log(error, 'error'))

//         return (

//             <div className=''>
//                 {Trans.length !== 0 ? Trans.map(tx => (
                    // <li className="t-hostory-li">
                    //     <span className="t-span-item">
                    //         <a href={`https://bscscan.com/tx/${tx.hash}`} target={'_blank'} className='t-h-link'>
                    //             {tx.hash}
                    //         </a>
                    //     </span>

                    //     <span className="t-span-item">{getTime(tx.timeStamp)}</span>
                    //     <span className="t-span-item">---</span>
                    //     <span className="t-span-item">---</span>
                    //     <span className="t-span-item">---</span>
                    //     <span className="t-span-item">
                    //         {formatUnits(tx.value)}
                    //     </span>
                    // </li>
//                 ))
//                     :
//                     <span className="font-13 padding-1rem-1rem">
//                         No Transaction By&nbsp;{window.address && window.address.slice(0, 4) + '****' + window.address.slice(-4)}
//                     </span>
//                 }
//             </div>
//         )
//     }
// }

// export default GetTransactionList