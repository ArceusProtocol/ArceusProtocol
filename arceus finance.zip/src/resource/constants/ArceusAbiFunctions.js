const AbiFunctions = [
    'function totalSupply() external view returns (uint256)',
    'function getCirculatingSupply() public view returns(uint256)',
    'function balanceOf(address who) external view returns (uint256)',
    'function nextClaimAmount(address account) public view returns (uint256)',
    'function nextClaimPeriod(address account) public view  returns (uint256)',
    'function claimTokens() external returns (uint256 Rewards, address Acount, uint256 timeStamp)',
    'function owner() public view returns (address)',
    'function lastRebaseTime() external view returns(uint)',
    'function factory() external pure returns (address)',
    'function getRebaseIndexes() view external returns(uint256)',
    'function trueRebase() public ',
    'function getAmountsOut(uint amountIn, address[] memory path) public view virtual override returns(uint[] memory amounts) ',
    'function name() public view returns (string memory)',
    'function symbol() public view returns(string memory)',
    'function autoRebaseState() external view returns(bool)',
    
    'function _referralEarning(address account) public view returns(uint256 earnings)',
    
    'function getReferralsByAddress(address _referee) external view returns(address [] memory myreferrals)',
    'function _autoRebase() public view returns(bool)',
    'function getPair(address tokenA, address tokenB) external view returns (address pair)',
    
    'function minBalance() public view returns(uint)',
    'function _autoAddLiquidity() public view returns(bool)',
    'function claimingInterval() public view returns(uint)',
    'function swapEnabled() public view returns(bool)',
    'function allowPartnerReward() public view returns(bool)',
    'function _minPartnerBalance() view public returns(uint256)',
    'function getAccountInfoMate(address account) external view returns(uint amount, uint nextTime, uint earnedSoFar, uint lastClaimTime, uint EarnedFromRef)',
    'function getRebaseInfo() external view returns(uint RebaseRate, uint RebaseTime, bool RebaseState)'

]
export default AbiFunctions