const ContractAddresses = {
    arceus: '0x83d1f4Da9CE614B3ACD06080eaf8adf6c2cB4BcF',
    pancakeRouter: '0x9ac64cc6e4415144c455bd8e4837fea55603e5c3',
    WETH: '0xae13d989daC2f0dEbFf460aC112a837C89BAa7cd',
    BUSD: '0x78867BbEeF44f2326bF8DDd1941a4439382EF2A7',


    PairContract: '0xDF0bDB5320537e41d911841BB8595598c673f0a9',
    treasuryReceiver: '0x005cC470102ED71B5EF506374f104fF50fcd541f',
    insuranceFundReceiver: '0x7Dba9Ad295860ed5Da42488cEe940f1B15Eb1621',
    firepitReceiver: '0x0921fB00871c87774b9A2465873c90c17a43Be26'
} 

export default ContractAddresses