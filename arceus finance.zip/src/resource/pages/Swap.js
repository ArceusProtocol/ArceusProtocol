import { GetIcon } from "../icons/ExportIcon"
import ContractAddresses from "../constants/ContractAddresses"
import { useEffect, useState } from 'react'
import DexInterface from "./dex/DexInterface"
import { useParams } from "react-router-dom"

function Swap({ params }) {
    const { tokenFrom, tokenTo } = useParams()
    const dexParms = { ...params, tokenFrom: tokenFrom, tokenTo: tokenTo }
    const { motion } = params
    const [wWidth, setwWidth] = useState(window.innerWidth)
    useEffect(() => window.addEventListener('resize', () => setwWidth(window.innerWidth)))

    return (
        <section className={`section ${wWidth <= 500 && 'notif'}`}>

            {/* <h2 className="h2-headline center-text">Swap ARC </h2> */}

            <div className='center-element'>

                <div className="counter-wrapper">

                    {/* <iframe
                        className="iframe-wrapper"
                        title="Bogged Finance"
                        id="boggedIframe"
                        style={{ display: 'none' }}
                        src="https://app.bogged.finance/bsc/swap?tokenIn=BNB&amp;tokenOut=0x22Ffa75b746602427203d7Aa3f9Dc2b8af6dFc8A&amp;embed=1&amp;theme=dark"
                    >
                    </iframe> */}



                    <div className="cards-wrapper swap-tkn">

                        <motion.span
                            initial={{ y: -100 }}
                            animate={{ y: 0 }}
                            exit={{ y: 100 }}
                            className="flex-grow font-13 text-paragraph tab-main flex-nowrap no-gray info">
                            <GetIcon icon={'info'} classname={'dex-icon no-grey'} />

                            ʻʻ As long as you buy and HODL Arceus, <br /> You will earn re-compounding interest, which is automatically paid directly to the HODLER's wallet every 25 minutes. ʼʼ
                        </motion.span>

                        {/* <h3 className="h3-headline p-1rem-0 w-full">Swap ARC</h3> */}
                        <div className="dex-wrap">

                            {tokenFrom && tokenTo ? <DexInterface params={dexParms} /> : ''}

                            <motion.div
                                className="dex-nav-btns"
                                initial={{ x: 100 }}
                                animate={{ x: 0 }}
                                exit={{ x: -100 }}>

                                {
                                    wWidth <= 500 && (
                                        <h3 className="h3-headline w-full"  >
                                            Other Trade Options:
                                        </h3>
                                    )
                                }


                                <a href={`https://pancakeswap.finance/swap`} target={'_blank'} className="flex-grow tab-main flex-nowrap no-gray">
                                    <GetIcon icon={'pancake'} classname={'dex-icon'} />
                                    <div className="card-content flex-colum">
                                        <h4 className="h4-headline m-none">Buy On Pancakeswap</h4>
                                        <span className='' href="//">Popular</span>
                                    </div>
                                </a>

                                <a href={`https://app.bogged.finance/bsc/swap?tokenIn=BNB&tokenOut=${ContractAddresses.arceus}`} target={'_blank'} className="flex-grow tab-main flex-nowrap no-gray">
                                    <GetIcon icon={'bogged'} classname={'dex-icon no-grey'} />
                                    <div className="card-content flex-colum">
                                        <h4 className="h4-headline m-none">Buy On Bogged Finance</h4>
                                        <span className='' href="//">Best price</span>
                                    </div>
                                </a>
                            </motion.div>
                        </div>

                    </div>



                </div>
            </div>
        </section>
    )
}

export default Swap