import { GetIcon } from "../icons/ExportIcon"
import { CountDownToDate } from "../reuseables/CountDown"
import NoData from "../reuseables/NoData"
import { useEffect, useState } from 'react'
// import GetTransactionList from "../reuseables/AllTransacrions"

function Token({ appname, params }) {

    const { motion } = params

    const [countDown, setcountDown] = useState()


    const PinsaleLink = (
        <div className="content ico-info">
            {/* <h3 className="h3-headline p-1rem-0 w-full">Swap ARC</h3> */}
            <a href={`#`} target={'_blank'} className="flex-nowrap no-gray">
                <GetIcon icon={'pinkswap'} classname={'dex-icon'} />
                {/* <div className="card-content flex-colum"> */}
                <h4 className="h4-headline m-none p-none">Private Sale On PinkSale</h4>
                {/* <a className='' href="//">Buy Now</a> */}
                {/* </div> */}
            </a>
        </div>
    )

    useEffect(() => {
        setInterval(() => {
            const { days, hours, minutes, seconds, ended, IcoStarted, PresaleEnded } = CountDownToDate(
                { presaleStart: '5 Jul 2022, 15:15:00', presaleEnd: '20 Jul 2022, 15:0:00' }
            )
            setcountDown(
                <div className="timer-wrapper ">
                    <h3 className="h3-headline p-1rem-0 w-full">
                        {
                            !IcoStarted && !PresaleEnded ? 'Presale starting soon.'
                                : IcoStarted && !PresaleEnded ? 'Presale ongoing'
                                    : IcoStarted && PresaleEnded ? "😐 Presale Ended!!!"
                                        : ''
                        }
                    </h3>
                    <div className="countDown-wrapper acc-list">
                        <div className="days">
                            <div className="numbers">{days} </div>
                            {days > 1 ? 'Days' : 'Day'}
                        </div>
                        <div className="hours">
                            <div className="numbers">{hours} </div>
                            {hours > 1 ? 'Hours' : 'Hour'}
                        </div>
                        <div className="minutes">
                            <div className="numbers">{minutes} </div>
                            {minutes > 1 ? 'Minutes' : 'Minute'}
                        </div>
                        <div className="seconds">
                            <div className="numbers">{seconds} </div>
                            {seconds > 1 ? 'Seconds' : 'Second'}
                        </div>
                    </div>

                    {IcoStarted && !PresaleEnded ? PinsaleLink : ''}
                </div>
            )
        }, 1000)
    }, [])

    return (
        <motion.section
            initial={{ opacity: 0, y: -100 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -100 }}
            className="section">
            <h2 className="h2-headline center-text">Arceus ICO</h2>

            <motion.div
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0, transition: { delay: .2 } }}
                viewport={{ once: false }}
                className='center-element padding-1rem flex-center'>
                <div className="counter-wrapper ">

                    {countDown}

                    <div className="w-600 " style={{ 'display': 'none' }}>
                        <details open className="no-p no-shadow acc-list">
                            <summary className="flex-nowrap space-between">
                                <h3 className="h3-headline summary-notation flex-nowrap">
                                    <GetIcon icon={'orderhistory'} classname='icon-size-21' />
                                    &nbsp;
                                    {'ARC ICO'}
                                </h3>

                                <h3 className="h3-headline summary-notation flex-nowrap">
                                    details
                                </h3>
                            </summary>


                            <ul className="ico-details">
                                <li className="ico-list">
                                    <span className="t-span-item flex-nowrap space-between">
                                        <i>Total supply</i>
                                        <i>3,250,000,000 ARC</i>
                                    </span>
                                    <span className="t-span-item flex-nowrap space-between">
                                        <i>Token for presale</i>
                                        <i>128,000 ARC</i>
                                    </span>
                                    <span className="t-span-item flex-nowrap space-between">
                                        <i>Tokens for liquidity</i>
                                        <i>804,802,400 ARC</i>
                                    </span>
                                    <span className="t-span-item flex-nowrap space-between">
                                        <i>Presale rate</i>
                                        <i>1BNB = 16 ARC</i>
                                    </span>
                                    <span className="t-span-item flex-nowrap space-between">
                                        <i>Listing rate</i>
                                        <i>1BNB = 197,280 ARC</i>
                                    </span>
                                    <span className="t-span-item flex-nowrap space-between">
                                        <i>Soft cap</i>
                                        <i>4000 BNB</i>
                                    </span>
                                    <span className="t-span-item flex-nowrap space-between">
                                        <i>Hard cap</i>
                                        <i>8000 BNB</i>
                                    </span>
                                    <span className="t-span-item flex-nowrap space-between">
                                        <i>Unsold tokens</i>
                                        <i>Burn</i>
                                    </span>
                                    <span className="t-span-item flex-nowrap space-between">
                                        <i>Presale start time</i>
                                        <i>----</i>
                                    </span>
                                    <span className="t-span-item flex-nowrap space-between">
                                        <i>Presale end time</i>
                                        <i>----</i>
                                    </span>
                                    <span className="t-span-item flex-nowrap space-between">
                                        <i>Listing</i>
                                        <i>Pinkswap / PnacakeSwap</i>
                                    </span>
                                    <span className="t-span-item flex-nowrap space-between">
                                        <i>Liquidity percent</i>
                                        <i>51%</i>
                                    </span>
                                    <span className="t-span-item flex-nowrap space-between">
                                        <i>Liquidity lockup time</i>
                                        <i>100 days after pool ends</i>
                                    </span>


                                </li>

                            </ul>
                            {/* <h1 className="h1-headline">
                                You're here on time !!!😎
                            </h1> */}
                        </details>
                    </div>

                </div>
            </motion.div>
        </motion.section>
    )
}

export default Token