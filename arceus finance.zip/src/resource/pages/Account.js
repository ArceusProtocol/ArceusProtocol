import { useEffect, useState } from "react"
import { GetIcon } from "../icons/ExportIcon"
import { CountDownSeconds } from "../reuseables/CountDown"
import { numberWithCommas, numFormatter } from "../reuseables/Numbers"
import { BigNumber, } from "ethers/lib/ethers"
import { formatUnits } from "ethers/lib/utils"
import { FetchTokenPriceBUSD } from "../reuseables/FetchTokenPrice"
import { useMoralis } from "react-moralis"
import IsAdmin from "../reuseables/IsAdmin"

function Account({ params }) {

    const { login,
        isAuthenticated,
        isAuthenticating,
        ArceusContract,
        dataLoading, PageLoading, marketPrice, showMessage, motion } = params

    const { Moralis } = useMoralis()

    const [dashData, setDashData] = useState({
        isAdmin: false,
        myBalance: 0,
        allRebaseIndexed: 0,
        nextRebaseTime: (<div className="lds-ripple"><div></div><div></div></div>),
        countDownMeter: 1400,
        nextRewardRoi: 0,
        nextRewardTokens: 0,
        currentRebaseRate: 0,
        referralEarning: 0,
        currentRebaseState: false,
        accountReferrals: []
    })

    useEffect(() => async () => {
        await IsAdmin()
            .then(response => setDashData(data => data = { ...data, isAdmin: String(response) }))
    })

    useEffect(() => {
        let session_done = true
        setInterval(async function () { 
            if (window.address != undefined) {
                if (session_done === true) {
                    session_done = false
                    await Promise.all([
                        ArceusContract.balanceOf(window.address),
                        FetchTokenPriceBUSD(0),
                        ArceusContract.getRebaseInfo(),
                        ArceusContract.getAccountInfoMate(window.address),
                    ])
                        .then(response => {
                            let balance = formatUnits(BigNumber.from(response[0]), '5')
                            let percentage = (balance / 100 * String(response[2].RebaseRate / 1000))
                            setDashData(data => data = {
                                ...data,
                                nextRewardTokens: percentage / 56,
                                myBalance: balance,
                                nextRewardRoi: Number(percentage).toFixed(3) * Number(response[1]),
                                nextRewardAmount: Number(percentage / 56).toFixed(5) * Number(response[1]),
                                currentRebaseRate: String(response[2].RebaseRate),
                                marketPrice: response[1],
                                referralEarning: formatUnits(String(response[3].EarnedFromRef), '5'),
                                // allRebaseIndexed: 'Times: ' + Number(getAllRebaseInxed),
                                // accountReferrals: response[3]
                            })
                            session_done = true
                        })
                }
            } else {
                setDashData(data => data = {
                    ...data,
                    nextRewardRoi: '---',
                    myBalance: 'no wallet detected.',
                    nextRewardTokens: '---'
                })
            }
        }, 1000);
    }, [])



    function copyAddress(event) {
        const copy = navigator.clipboard.writeText(event.target.name)
        if (copy) {
            showMessage({
                type: 'success',
                content: <span>Referral Address Copied..</span>,
                solution: null
            })
        }
    }

    const ArbitragePersonalInfo = (
        <></>
    )


    const ROIRates = (
        <motion.ul
            initial={{ opacity: 0, x: -100 }}
            whileInView={{ opacity: 1, x: 0, transition: { delay: .2 } }}
            viewport={{ once: false }}
            className='t-history-ul alone'>
            <li className="t-hostory-li">
                <span className="t-span-item no-padding"> Your Balance </span>
                <span className="t-span-item">
                    {isAuthenticated ? 'ARC ' + numFormatter(dashData.myBalance) : isAuthenticating ? 'Loading...' : 'please log in'}
                </span>
                <span className="t-span-item">
                    $ {isAuthenticated ? numberWithCommas(Number(dashData.myBalance * dashData.marketPrice).toFixed(3)) : isAuthenticating ? 'Authenticating...' : '-----'}
                </span>
            </li>

            <li className="t-hostory-li">
                <span className="t-span-item no-padding">On Rebase</span>
                <span className="t-span-item">
                    56x Daily
                </span>
                <span className="t-span-item">
                    {dashData.currentRebaseRate / 1e5}% E&bull;T
                </span>
            </li>

            <li className="t-hostory-li">
                <span className="t-span-item no-padding">Next Reward</span>
                <span className="t-span-item">ARC {numFormatter(Number(dashData.nextRewardTokens).toFixed(3))} </span>
                <span className="t-span-item">$ {numberWithCommas(Number(dashData.nextRewardTokens * dashData.marketPrice).toFixed(3))} </span>
            </li>

            <li className="t-hostory-li">
                <span className="t-span-item no-padding"> Daily ROI </span>
                <span className="t-span-item">{dashData.currentRebaseRate / 1e5 * 100}%</span>
                <span className="t-span-item">$ {numberWithCommas(Number(dashData.nextRewardRoi).toFixed(3))} </span>
            </li>

            <li className="t-hostory-li">
                <span className="t-span-item no-padding"> 20 Days ROI </span>
                <span className="t-span-item">{((dashData.currentRebaseRate / 1e5) * (100)) * 20}%</span>
                <span className="t-span-item">$ {numberWithCommas(Number(dashData.nextRewardRoi * 20).toFixed(2))}</span>
            </li>

            <li className="t-hostory-li">
                <div className="flex-nowrap space-between">
                    <button className="primary-btn middle-all flex-nowrap no-shadow no-gray">
                        Rebasing  &nbsp; <GetIcon icon={'spinner'} classname='spinner' />
                    </button>
                </div>
            </li>

        </motion.ul>
        // </div>
    )

    const Referrals = (
        <div className="card-main">
            <h4 className="h4-headline">Earned From Referrals?</h4>
            <span className="font-13" style={{ 'lineHeight': '2' }}>
                ARC {Number(dashData.referralEarning).toFixed(5)}
                &nbsp; &cong; &nbsp;
                $ {Number(dashData.referralEarning * dashData.marketPrice).toFixed(5)}
            </span>
            <div className="card-content" style={{ 'lineHeight': '2' }}>for partners:  <a href="" className="font-13 active padding-dot2em">Join</a></div>
            <details className="no-shadow w-full no-padding">
                <summary className="flex-nowrap space-between">
                    <h3 className="h3-headline summary-notation flex-nowrap no-gray">
                        <GetIcon icon={'centralizednetwork'} classname='icon-size-21' />
                        &nbsp;
                        View Your Downlines
                    </h3>
                    <span className="font-13">{dashData.accountReferrals.length} Downlines</span>
                </summary>

                <ul className='t-history-ul alone'>
                    {/* <li className="t-hostory-li">
                        <span className="t-span-item">Referral Address </span>
                        <span className="t-span-item">Referee Actions </span>
                    </li> */}
                    {
                        dashData.accountReferrals.length > 0 ?
                            dashData.accountReferrals.map(
                                account => {
                                    if (account != '0x0000000000000000000000000000000000000000') {
                                        return (
                                            <li className="t-hostory-li">
                                                <span className="t-span-item no-padding">
                                                    <a href={window.explorer + '/address/' + account} target={'_blank'} className='no-padding t-h-link'>
                                                        {account}
                                                    </a>
                                                </span>
                                                <span className="t-span-item">
                                                    <button
                                                        className={`primary-btn  ${dashData.swapState === true ? 'active' : 'inactive'}`}
                                                        name={account}
                                                        onClick={(event) => copyAddress(event)} >
                                                        Copy Address
                                                    </button>
                                                </span>
                                            </li>
                                        )
                                    }
                                }
                            )
                            : !isAuthenticated ? 'Signin.' : 'You Have Not Referred Anyone Yet. 😔😓'
                    }
                </ul>
            </details>
        </div>
    )

    // const RebaseInfo = (
    //     <div className="dash-count-down stand-alone right" style={{ 'max-width': '800px' }}>
    //         <div className="card-main">
    //             <h4 className="h4-headline">Your Balance</h4>
    //             <div className="card-content flex-nowrap no-gray">
    //                 <GetIcon icon={isAuthenticating ? 'spinner' : 'usd'} classname={isAuthenticating ? 'spinner' : null} />
    //                 {isAuthenticated ? dashData.myBalance * dashData.marketPrice : isAuthenticating ? 'Authenticating...' : '-----'}
    //             </div>
    //             <div className="card-content" onClick={isAuthenticated ? undefined : login} >
    //                 {isAuthenticated ? 'ARC ' + numFormatter(dashData.myBalance) : isAuthenticating ? 'Loading...' : 'please log in'}
    //             </div>
    //         </div>

    //         <div className="card-main">
    //             <h4 className="h4-headline flex-nowrap space-between">
    //                 <div className="card-content">@Rebase</div>
    //                 <div className="card-content"></div>
    //             </h4>
    //             <div className="flex-nowrap space-between">
    //                 <div className="card-content">daily ROI</div>
    //                 <div className="card-content"></div>
    //             </div>
    //             <div className="card-actions-wrap">
    //                 <a className="card-action" href="/@/swap">Start Earning ARC</a>
    //             </div>
    //         </div>
    //     </div>
    // )

    return (
        <motion.section
            initial={{ opacity: 0, y: -100 }}
            whileInView={{ opacity: 1, y: 0, transition: { delay: .2 } }}
            viewport={{ once: false }}
            className="section">
            {/* <h2 className="h2-headline center-text">Account</h2> */}

            <div className='center-element acc-list'>
                <div className="counter-wrapper">
                    <div className="cards-wrapper">

                        {/* <div className="card-main">
                            <h4 className="h4-headline flex-nowrap space-between">
                                Next Rebase:
                                <GetIcon icon={'spinner'} classname={'spinner'} />
                            </h4>
                            <div className="card-content">
                                {dashData.nextRebaseTime}
                            </div>
                            <div className="card-content flex-nowrap">
                                <i className="rtstatus qrt-status-current"></i>
                                {dashData.isAdmin === 'true' ? dashData.allRebaseIndexed :
                                    <meter
                                        value={dashData.countDownMeter}
                                        className='meter'
                                        high={1400}
                                        max='1500'
                                        min={0}
                                        low={600}
                                        optimum={400}
                                    >
                                    </meter>
                                }
                            </div>
                        </div> */}

                        {ROIRates}

                        {Referrals}

                    </div>
                </div>
            </div>
        </motion.section>
    )
}

export default Account