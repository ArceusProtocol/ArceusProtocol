import { useEffect, useState } from "react"
import { GetIcon } from "../icons/ExportIcon"
import { numFormatter } from "../reuseables/Numbers"
import { BigNumber, } from "ethers/lib/ethers"
import { formatUnits, formatEther } from "ethers/lib/utils"
import { FetchTokenPriceBUSD } from "../reuseables/FetchTokenPrice"
import { useMoralis } from "react-moralis"
import { ArceusTokenContract } from '../reuseables/ContractInitialized'

function Calculator({ appname, params }) {

    const {
        login,
        address,
        isAuthenticated,
        isAuthenticating,
        dataLoading,
        marketPrice,
        ArceusContract,
        motion
    } = params


    const [dashData, setDashData] = useState({
        currentRebaseRate: 0,
        isAdmin: false,
        marketPrice: 0,
        allRebaseIndexed: 0,
        investmentAmount: 1,
        initialInvestment: 0,
        currentWealth: 0,
        rewardEstimate: 0,
        potentialReturn: 0,
        myBalance: dataLoading,
        purchasePrice: 0,
        investDays: 1,
        yearOneRange: 0,
        marketPrice: 0,
        currentRebaseRate: 0
    })

    useEffect(() => {
        let session_done = true
        setInterval(async () => {
            if (session_done === true) {
                session_done = false
                const [getmarketprice, getRebaseRate] = await Promise.all([
                    FetchTokenPriceBUSD(0),
                    ArceusContract.getRebaseInfo()
                ])

                setDashData(data => data = {
                    ...data,
                    purchasePrice: getmarketprice,
                    marketPrice: getmarketprice,
                    currentRebaseRate: String(getRebaseRate.RebaseRate)
                })
                if (window.address != undefined) {
                    const getMyBalance = await ArceusTokenContract.balanceOf(window.address)
                    setDashData(data => data = {
                        ...data,
                        myBalance: numFormatter(formatUnits(BigNumber.from(getMyBalance), '5'))
                    })
                } else {
                    setDashData(data => data = {
                        ...data,
                        myBalance: 'wallet not connected. 😐'
                    })
                }
                session_done = true
            }
        }, 1000);
    }, [])



    function handleInvestmentAmountChange(event) {
        let value = event.target.value
        setDashData(data => data = {
            ...data,
            rewardEstimate: calculateRewardEstimate(value, dashData.investDays),
            currentWealth: calculateCurrentWealth((value * dashData.purchasePrice).toFixed(2)),
            initialInvestment: numFormatter(value * dashData.marketPrice),
            investmentAmount: value
        })
    }

    function handlePurchasePriceChange(event) {
        const Evlaue = event.target.value
        setDashData(data => data = {
            ...data,
            initialInvestment: numFormatter(dashData.investmentAmount * Evlaue)
        })
    }

    function firstYearRange(event) {
        const Evlaue = event.target.value
        setDashData(data => data = {
            ...data,
            investDays: Evlaue,
            yearOneRange: Evlaue,
        })
        calculateRewardEstimate(dashData.investmentAmount, Evlaue)
    }

    function calculateCurrentWealth(cw) {
        setDashData(data => data = {
            ...data,
            currentWealth: cw
        })
    }

    async function calculateRewardEstimate(amt, days) {
        let R, A, P, N = dashData.currentRebaseRate
        R = dashData.currentRebaseRate / 100
        P = amt * Math.pow((1 + (R / N)), (days))
        setDashData(data => data = {
            ...data,
            rewardEstimate: dataLoading,
            potentialReturn: dataLoading
        })
        A = P.toFixed(5)
        setTimeout(() => {
            setDashData(data => data = {
                ...data,
                rewardEstimate: A,
                potentialReturn: (A * dashData.marketPrice).toFixed(5)
            })
        }, 300)
    }

    function calculatePotentialReturn(amt) {
        setDashData(data => data = {
            ...data,
            potentialReturn: amt
        })
    }

    function handleFuturePrice(e) {
        let futurePrice = e.target.value
        if (futurePrice === '0' || futurePrice === '') {
            futurePrice = dashData.marketPrice
        }
        let amt = dashData.rewardEstimate * futurePrice
        calculatePotentialReturn(amt)
    }


    return (
        <motion.section
            initial={{ width: 0 }}
            animate={{ width: '100%' }}
            exit={{ width: 0 }}
            className="section">
            <h2 className="h2-headline center-text">Arceus ROI</h2>

            <div className='center-element padding-1rem acc-list'>
                <div className="counter-wrapper">
                    <div className="cards-wrapper ">
                        <div className="calculator-wrapper   flex-wrap space-between">

                            {/* 
                        <div className="flex-wrap space-between w-full">
                            <div className="card-main">
                                <h4 className="h4-headline">{appname} price?</h4>
                                <div className="card-content">$ {dashData.marketPrice}</div>
                            </div>
                            <div className="card-main">
                                <h4 className="h4-headline">Daily ROI?</h4>
                                <div className="card-content">{(dashData.currentRebaseRate / 1e5) * 100}%</div>
                            </div>
                            <div className="card-main">
                                <h4 className="h4-headline">Your Balance?</h4>
                                <div
                                    className="card-content"
                                    onClick={!isAuthenticated ? login : undefined}>
                                    {isAuthenticated ? 'ARC '+ (dashData.myBalance) : isAuthenticating ? 'loading...' : 'login'}
                                </div>
                            </div>
                        </div> */}

                            <div className="swap-input-main flex-column">
                                <div className="card-content flex-nowrap space-between">
                                    <span className="side-name"> Amount (ARC)?</span>
                                </div>

                                <div className="swap-input-inner  flex-nowrap space-between">
                                    <motion.input
                                        step={0.1}
                                        className="swap-int-input"
                                        placeholder={'ARC ' + 10}
                                        pattern='[0.0-9]+'
                                        type={'number'}
                                        onChange={handleInvestmentAmountChange}
                                        whileHover={{ scale: 1.1 }}
                                        whileTap={{ scale: 0.9 }}
                                        whileFocus={{ scale: 1.05 }}
                                    />

                                </div>
                            </div>

                            <div className="swap-input-main flex-column">
                                <div className="card-content flex-nowrap space-between">
                                    <span className="side-name">Current Daily ROI (%)?</span>
                                </div>

                                <div className="swap-input-inner flex-nowrap space-between">
                                    <input
                                        className="swap-int-input"
                                        type={'number'}
                                        value={(dashData.currentRebaseRate / 1e5) * 100}
                                        readOnly
                                        disabled={true}
                                        whileHover={{ scale: 1.1 }}
                                        whileTap={{ scale: 0.9 }}
                                        whileFocus={{ scale: 1.05 }}
                                    />
                                </div>
                            </div>

                            <div className="swap-input-main flex-column">
                                <div className="card-content flex-nowrap space-between">
                                    <span className="side-name">(ARC) price at purchase ($)?</span>
                                </div>

                                <div className="swap-input-inner flex-nowrap space-between">
                                    <motion.input
                                        className="swap-int-input"
                                        placeholder={'$ ' + dashData.purchasePrice}
                                        type={'number'}
                                        min={0.005}
                                        // value={dashData.purchasePrice}
                                        onChange={handlePurchasePriceChange}
                                        whileHover={{ scale: 1.1 }}
                                        whileTap={{ scale: 0.9 }}
                                        whileFocus={{ scale: 1.05 }}
                                    />

                                </div>
                            </div>

                            <div className="swap-input-main flex-column">
                                <div className="card-content flex-nowrap space-between">
                                    <span className="side-name">Future ARC Price ($)?</span>
                                </div>

                                <div className="swap-input-inner flex-nowrap space-between">
                                    <motion.input
                                        placeholder={'$ ' + dashData.marketPrice}
                                        className="swap-int-input"
                                        type={'number'}
                                        onChange={handleFuturePrice}
                                        whileHover={{ scale: 1.1 }}
                                        whileTap={{ scale: 0.9 }}
                                        whileFocus={{ scale: 1.05 }}
                                    />

                                </div>
                            </div>


                            <div className="flex-wrap space-between w-full negave">
                                <div className="swap-input-inner flex-wrap space-between">
                                    <div className="card-content flex-nowrap space-between">
                                        <span className="side-name">
                                            {dashData.investDays > 1 ? dashData.investDays + 'Days' : dashData.investDays + 'Day'} &bull; Investment?
                                        </span>
                                    </div>
                                    <input
                                        step={1}
                                        className="swap-int-input"
                                        type={'range'}
                                        min={1}
                                        max={710}
                                        value={dashData.yearOneRange}
                                        onChange={firstYearRange}
                                    />
                                </div>
                            </div>


                            <details open className="no-p no-shadow">
                                <summary className="flex-nowrap space-between">
                                    <h3 className="h3-headline summary-notation flex-nowrap">
                                        <GetIcon icon={'growingmoney'} classname='icon-size-21' />
                                        &nbsp;
                                        {'Potentail ROI'}
                                    </h3>

                                    <h3 className="h3-headline summary-notation flex-nowrap">
                                        &bull;&bull;&bull;
                                    </h3>
                                </summary>

                                <div className="ico-dashboard">

                                    <div className="ico-dash-tabs">
                                        <span>Initial Investment: </span>
                                        <span>{'$'} {dashData.initialInvestment} </span>
                                    </div>

                                    <div className="ico-dash-tabs">
                                        <span>Current Wealth: </span>
                                        <span>{'$'} {dashData.currentWealth}</span>
                                    </div>

                                    <div className="ico-dash-tabs">
                                        <span>Rewards Estimation: </span>
                                        <span>{dashData.rewardEstimate}</span>
                                    </div>

                                    <div className="ico-dash-tabs">
                                        <span>Potential Return: </span>
                                        <span>{'$'} {dashData.potentialReturn}</span>
                                    </div>
                                </div>
                            </details>

                        </div>
                    </div>
                </div>
            </div>
        </motion.section>
    )
}

export default Calculator