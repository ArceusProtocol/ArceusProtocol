import { useSwiper } from 'swiper/react'
import { useRef, useState } from 'react'
import { GetIcon } from '../dex/icons/ExportIcon'

function ArbitrageUi({ params }) {
    const { isAuthenticated, SwiperSlide, Swiper, swpierModules, useSwiperSlide, motion } = params

    let ref = useRef()
    // const isMatchMediaMobile = window.matchMedia("(max-width: 775px)").matches
    const isNavigatorAgentMobile = (/android|webos|iphone|ipad|ipod|blackberry|iemobile|opera mini/i.test(navigator.userAgent.toLowerCase()))
    // !isMatchMediaMobile && 


    const BaseTokenOptions = [
        { value: 'BUSD', label: 'BUSD' },
        { value: 'BNB', label: 'BNB' },
        { value: 'USDT', label: 'USDT' }
    ]

    const [dashData, setDashData] = useState({
        selectedToken: BaseTokenOptions[0].label,
        showBaseTokens: false
    })

    function selectTokenToDeposit(depositAsset) {
        setDashData(data => data = { ...data, selectedToken: depositAsset.target.innerText, showBaseTokens: false })
    }

    if (!isNavigatorAgentMobile) {
        return (
            <div className="abi-ui-wrapper" >
                <h1>ARCEUS ARBITRA-D-E</h1>
                {isAuthenticated}

                <div className="abi-ui-inner-wrapper" >
                    <Swiper
                        spaceBetween={50}
                        slidesPerView={1}
                        modules={swpierModules}
                        loop={true}
                        effect={'cube'}
                        nested={true}
                        onSwiper={(swiper) => { ref.current = swiper }}
                    >
                        <SwiperSlide className={'abi-ui-inner-dash-slide'}>
                            <h3 className="h3-headline">PERSONAL STATS</h3>
                            <div className='abi-dash-card'>
                                <div className='abi-dash-boldinline'>
                                    <motion.div className='abi-dash-card-mini'>
                                        <h4 className="h4-headline">Deposits?</h4>
                                        <div className="abi-dash-card-content flex-nowrap">BUSD 0.00</div>
                                    </motion.div>
                                    <motion.div className='abi-dash-card-mini'>
                                        <h4 className="h4-headline">Withdrawals?</h4>
                                        <div className="abi-dash-card-content flex-nowrap">BUSD 0.00</div>
                                    </motion.div>
                                    <motion.div className='abi-dash-card-mini'>
                                        <h4 className="h4-headline">Your Position?</h4>
                                        <div className={`abi-dash-card-content flex-nowrap inactive-color`}>BUSD 0.00</div>
                                    </motion.div>
                                    <motion.div className='abi-dash-card-mini'>
                                        <h4 className="h4-headline">Profits Earned?</h4>
                                        <div className="abi-dash-card-content flex-nowrap">BUSD 0.00</div>
                                    </motion.div>

                                    <motion.div className='abi-dash-card-mini'>
                                        <h4 className="h4-headline">Potential Dividend?</h4>
                                        <div className="abi-dash-card-content flex-nowrap">BUSD 0.00</div>
                                    </motion.div>

                                    <motion.div className='abi-dash-card-mini'>
                                        <h4 className="h4-headline">Profits Earned?</h4>
                                        <div className="abi-dash-card-content flex-nowrap">BUSD 0.00</div>
                                    </motion.div>
                                </div>

                                <div className='abi-dash-toggle-actions'>
                                    <div className='abi-dash-switch-tab-nav'>
                                        <div className='abi-dash-btn-wrap'>
                                            <button className='abi-dash-slide-btn button-prev'>Deposit</button>
                                            <button className='abi-dash-slide-btn button-next'>Withdraw</button>
                                        </div>
                                        <div className=''> </div>
                                    </div>
                                    <Swiper
                                        slidesPerView={1}
                                        spaceBetween={0}
                                        modules={swpierModules}
                                        speed={500}
                                        focusableElements='input, select, option,select, textarea, button, video, label'
                                        simulateTouch={true}
                                        navigation={{ nextEl: '.button-next', prevEl: '.button-prev' }}
                                    >

                                        <SwiperSlide>
                                            <motion.div
                                                initial={{ x: -100 }}
                                                exit={{ x: 100 }}
                                                whileInView={{ opacity: 1, x: 0 }}
                                                viewport={{ once: false }}
                                                className='abi-dash-input-wrapper'>
                                                <label>DEPOSIT</label>
                                                <div className='abi-dash-input-param-wrap'>
                                                    <div className='abi-selector-wrap'>
                                                        <input readOnly
                                                            onClick={() => setDashData(D => D = { ...D, showBaseTokens: true })}
                                                            value={dashData.selectedToken}
                                                            className='selected-display' />
                                                        {dashData.showBaseTokens &&
                                                            <motion.ul
                                                                initial={{ x: -100 }}
                                                                animate={{ x: 0, y: '-50%' }}
                                                                exit={{ x: 100 }}
                                                                className='abi-dash-selector'>
                                                                {BaseTokenOptions.map(
                                                                    token => { return (<li onClick={selectTokenToDeposit} className='abi-dash-options' value={token.value}>{token.label}</li>) }
                                                                )}
                                                            </motion.ul>
                                                        }
                                                    </div>
                                                    <input
                                                        placeholder={`amount in: ${dashData.selectedToken}`}
                                                        className='abi-dash-input-param'
                                                        type='number'
                                                        dir="rtl" />
                                                </div>
                                            </motion.div>
                                        </SwiperSlide>


                                        <SwiperSlide>
                                            <motion.div
                                                initial={{ x: 100 }}
                                                whileInView={{ opacity: 1, x: 0 }}
                                                viewport={{ once: false }}
                                                exit={{ x: -100 }}
                                                className='abi-dash-input-wrapper'>
                                                <label>WITHDRAW</label>
                                                <div className='abi-dash-input-param-wrap'>
                                                    <input className='abi-dash-input-param' type={'text'} />
                                                </div>
                                            </motion.div>
                                        </SwiperSlide>
                                    </Swiper>
                                </div>
                            </div>
                        </SwiperSlide>



                        <SwiperSlide className={'abi-ui-inner-dash-slide'}>
                            <h2 className='h2-headline not-available' style={{ backgorund: 'transparent', color: 'rgb(118, 118, 118)' }}>
                                Feature 1 Coming Soon!!
                            </h2>
                        </SwiperSlide>
                        <SwiperSlide className={'abi-ui-inner-dash-slide'}>
                            <h2 className='h2-headline not-available' style={{ backgorund: 'transparent', color: 'rgb(118, 118, 118)' }}>
                                Feature 2 Coming Soon!!
                            </h2>
                        </SwiperSlide>
                        <SwiperSlide className={'abi-ui-inner-dash-slide'}>
                            <h2 className='h2-headline not-available' style={{ backgorund: 'transparent', color: 'rgb(118, 118, 118)' }}>
                                Feature 3 Coming Soon!!
                            </h2>
                        </SwiperSlide>
                    </Swiper>
                </div>

                {/* <div className="abi-ui-dash-nav-wrapper">
                <button onClick={() => ref.current.slideTo(1, 3000, false)} className="abi-ui-dash-butns">My Position</button>
                <button onClick={() => ref.current.slideTo(2, 3000, false)}  className="abi-ui-dash-butns">Gen. Statistics</button>
                <button onClick={() => ref.current.slideTo(3, 3000, false)}  className="abi-ui-dash-butns">My Transations</button>
                <button onClick={() => ref.current.slideTo(4, 3000, false)}  className="abi-ui-dash-butns">Statistics</button>
            </div> */}
                {/* {navigator.userAgent} */}

            </div >
        )
    } else {
        return (
            <h2 className='h2-headline not-available' style={{ padding: '1rem', background: 'red' }}>
                Please Use "Desktop" To View THis Page
                {/* {navigator.userAgent} */}
            </h2>
        )
    }
}

export default ArbitrageUi