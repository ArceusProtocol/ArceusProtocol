import { useState, useEffect } from "react"
import { numberWithCommas, numFormatter } from "../reuseables/Numbers"
import { useMoralis } from "react-moralis"
import ArceusAbi from '../constants/ArceusAbi.json'
import ContractAddresses from "../constants/ContractAddresses"
import { formatEther, formatUnits, parseUnits } from "ethers/lib/utils"
import { FetchBNBPriceBUSD, FetchTokenPriceBUSD } from "../reuseables/FetchTokenPrice"
import IsAdmin from "../reuseables/IsAdmin"
import { getDayTimeGreeting } from "../reuseables/CountDown"
import { BigNumber, ethers } from 'ethers';
import AbiFunctions from "../constants/ArceusAbiFunctions"
import { CountDownWithAnim, getTime } from "../reuseables/CountDown"
import { GetIcon } from '../icons/ExportIcon'
import SocialLinks from "../reuseables/SocialLinks"


function Dashboard({ params }) {
    const [wWidth, setwWidth] = useState(window.innerWidth)
    useEffect(() => window.addEventListener('resize', () => setwWidth(window.innerWidth)))
    const { enableWeb3, Moralis } = useMoralis()

    const {
        ArceusContract,
        dataLoading,
        treasuryReceiver,
        insuranceFundReceiver,
        showMessage, PageLoading, motion } = params

    const [dashData, setDashData] = useState({
        totalSupply: 0,
        circulatingSupply: 0,
        treasuryWallet: 0,
        insuranceWallet: 0,
        insuranceFundValue: 0,
        treasuryFundValue: 0,
        firePitWallet: 0,
        marketCap: dataLoading,
        currentRebaseRate: 0,
        newRebaserate: 0,
        autoLiquidityState: false,
        autoRebaseState: false,
        swapState: false,
        parnershipState: false,
        ArceuspoolValue: dataLoading,
        dayTimeGreeting: 'welcome',
        isAdmin: false,
        tokenToWithdrawAddress: ContractAddresses.arceus,
        tokenToWithdrawBalance: '👈 Enter Token Address',
        nextRebaseTime: (<div className="lds-ripple"><div></div><div></div></div>),
        marketPrice: 0,
        allRebaseIndexed: 0,
        partnerSymbol: 'enter name or symbol here.',
        partnerAddress: 'enter an address here.',
        allPartners: '',
        referralEarnings: '',
        refereeAddress: 'Enter Address To get Referral Earnings.',
        newPartnerMinBalance: 2,
        currentMinPartnerbalance: 0,
        allLoaded: false,
        amounttokenstoBurn: 0
    })

    useEffect(() => async () => {
        await IsAdmin().then(response => {
            if (response) {
                setDashData(data => data = {
                    ...data,
                    dayTimeGreeting: getDayTimeGreeting(),
                    isAdmin: String(response)
                })
            }
        })
    })

    useEffect(() => {
        let session_done = true
        setInterval(async () => {
            if (session_done === true) {
                session_done = false
                await Promise.all([
                    ArceusContract.totalSupply(),
                    ArceusContract.getCirculatingSupply(),
                    ArceusContract.balanceOf(treasuryReceiver),
                    ArceusContract.balanceOf(insuranceFundReceiver),
                    ArceusContract.balanceOf(ContractAddresses.PairContract),
                    ArceusContract.balanceOf(ContractAddresses.firepitReceiver),
                    ArceusContract.getRebaseInfo(),
                    ArceusContract._autoAddLiquidity(),
                    ArceusContract.swapEnabled(),
                    ArceusContract.allowPartnerReward(),
                    FetchTokenPriceBUSD(0),
                    ArceusContract._minPartnerBalance(),
                    window.provider.getBalance(insuranceFundReceiver),
                    window.provider.getBalance(treasuryReceiver),
                ])
                    .then(async response => {
                        const [InsuranceFund, TreasuryFund] = await Promise.all([
                            FetchBNBPriceBUSD(formatEther(String(response[12]) > 0 ? String(response[12]) : parseUnits('0.00000001'))),
                            FetchBNBPriceBUSD(formatEther(String(response[13]) > 0 ? String(response[13]) : parseUnits('0.00000001'))),
                        ])
                        setDashData(data => data = {
                            ...data,
                            totalSupply: numFormatter(formatUnits(BigNumber.from(response[0]), '5')),
                            circulatingSupply: formatUnits(BigNumber.from(response[1]), '5'),
                            treasuryWallet: Number(response[2]),
                            insuranceWallet: Number(response[3]),
                            ArceuspoolValue: Number(formatUnits(response[4], '5') * response[10]) * (2),
                            marketCap: formatUnits(BigNumber.from(response[1]), '5') * response[10],
                            firePitWallet: Number(response[5]),
                            autoRebaseState: response[6].RebaseState,
                            currentRebaseRate: Number(response[6].RebaseRate),
                            newRebaserate: Number(response[6].RebaseRate),
                            autoLiquidityState: response[7],
                            swapState: response[8],
                            parnershipState: response[9],
                            marketPrice: response[10],
                            currentMinPartnerbalance: formatUnits(String(response[11]), '5'),
                            insuranceFundValue: InsuranceFund,
                            treasuryFundValue: TreasuryFund,
                            allLoaded: true
                        })
                    })
                    .catch(error => {
                        console.info(error, 'error')
                        session_done = true;
                    })
                session_done = true
            }
        }, 1000)
    }, [])


    // useEffect(() => {

    //     let wait_full = true

    //     async function RaceLastRebaseTime() {

    //         const [infoLastRebseTime, autoRebaseState] = await Promise.all([
    //             ArceusContract.lastRebaseTime(),
    //             ArceusContract.autoRebaseState(),
    //         ])

    //         setDashData(data => data = {
    //             ...data,
    //             currentRebaseState: String(autoRebaseState)
    //         })

    //         if (1400 - Number(infoLastRebseTime) === 0 && wait_full === true) {
    //             wait_full = false
    //             await ArceusContract.trueRebase()
    //                 .then(async done => {
    //                     done.wait()
    //                         .then(processed => processed && window.location.reload())
    //                 })
    //                 .catch(error => {
    //                     if (dashData.isAdmin === 'true') {
    //                         showMessage({
    //                             type: 'error',
    //                             content: <span>{error.reason}</span>,
    //                             solution: null
    //                         })
    //                         setDashData(data => data = {
    //                             ...data,
    //                             nextRebaseTime: 'Could not load data.'
    //                         })
    //                     }
    //                 })
    //         } else { CountDownTillNextRebase(infoLastRebseTime) }
    //     }

    //     function CountDownTillNextRebase(lastRebaseTime) {
    //         let countFrom = (1400 - Number(lastRebaseTime))
    //         setInterval(() => {
    //             if (countFrom === 0) {
    //                 setDashData(data => data = { ...data, nextRebaseTime: (<div className="lds-ripple"><div></div><div></div></div>) })
    //                 RaceLastRebaseTime()
    //             } else {
    //                 setDashData(data => data = { ...data, nextRebaseTime: CountDownWithAnim(countFrom) })
    //                 countFrom -= 1
    //             }
    //         }, 1000);
    //     }
    //     RaceLastRebaseTime()

    // }, [])

    async function withdrawAllToTreasury() {
        const options = {
            functionName: 'withdrawAllToTreasury',
            contractAddress: ContractAddresses.arceus,
            abi: ArceusAbi,
            chain: window.chain,
            params: {}
        }

        await Moralis.executeFunction(options)
            .then(async response => {
                await response.wait()
                    .then(confirmed => {
                        showMessage({
                            type: 'success',
                            content: <span>Confirmations: {String(confirmed.confirmations)}</span>,
                            solution: window.explorer + `/tx/${confirmed.hash}`
                        })
                    })
            })
            .catch(error => {
                showMessage({
                    type: 'error',
                    content: error.data.message,
                    solution: null
                })
            })
    }

    async function handleTokenToWithdraw(event) {
        const asset = event.target.value
        setDashData(data => data = {
            ...data,
            tokenToWithdrawAddress: asset === undefined ? ContractAddresses.arceus : asset,
            tokenToWithdrawBalance: dataLoading,
        })

        const token = new ethers.Contract(asset, AbiFunctions, window.provider)
        const [balance, symbol] = await Promise.all([
            token.balanceOf(ContractAddresses.arceus),
            token.symbol()
        ])

        setDashData(data => data = {
            ...data,
            tokenToWithdrawBalance: 'Withdraw (' + symbol + ') ' + numFormatter(Moralis.Units.FromWei(balance, '5')),
        })
    }

    async function withdrawAllETH(params) {
        const options = {
            contractAddress: ContractAddresses.arceus,
            functionName: 'rescueNative',
            abi: ArceusAbi,
            chain: window.chain,
        }

        await Moralis.executeFunction(options)
            .then(async response => {
                showMessage({ type: 'success', content: dataLoading })
                await response.wait().then(
                    confirmed => {
                        if (confirmed) {
                            showMessage({
                                type: 'success',
                                content: <span>Confirmations: {String(confirmed.confirmations)}</span>,
                                solution: window.explorer + `/tx/${confirmed.hash}`
                            })
                        }
                    }
                )
            })
            .catch(error => {
                showMessage({
                    type: 'error',
                    content: error.data.message,
                    solution: null
                })
            })
    }

    async function withdrawERC20Token() {
        const options = {
            functionName: 'rescueErc20',
            contractAddress: ContractAddresses.arceus,
            abi: ArceusAbi,
            chain: window.chain,
            params: {
                asset: dashData.tokenToWithdrawAddress
            }
        }

        await Moralis.executeFunction(options)
            .then(async response => {
                showMessage({ type: 'success', content: dataLoading })
                await response.wait().then(
                    confirmed => {
                        if (confirmed) {
                            showMessage({
                                type: 'success',
                                content: <span>Confirmations: {String(confirmed.confirmations)}</span>,
                                solution: window.explorer + `/tx/${confirmed.hash}`
                            })
                        }
                    }
                )
            })
            .catch(error => {
                showMessage({
                    type: 'error',
                    content: error.data.message,
                    solution: null
                })
            })
    }

    async function toggleAutoAddliquidity() {
        const options = {
            contractAddress: ContractAddresses.arceus,
            functionName: 'setAutoAddLiquidity',
            chain: window.chain,
            abi: ArceusAbi,
            params: {
                _flag: !dashData.autoLiquidityState
            }
        }

        await Moralis.executeFunction(options)
            .then(response => response && window.location.reload())
            .catch(error => {
                showMessage({
                    type: 'error',
                    content: <span>{error.reason}</span>,
                    solution: null
                })
            })
    }

    async function toggleAutoRebase() {
        const options = {
            contractAddress: ContractAddresses.arceus,
            functionName: 'setAutoRebase',
            chain: window.chain,
            abi: ArceusAbi,
            params: {
                _flag: !dashData.autoRebaseState
            }
        }

        await Moralis.executeFunction(options)
            .then(response => response && window.location.reload())
            .catch(error => {
                showMessage({
                    type: 'error',
                    content: <span>{error.reason}</span>,
                    solution: null
                })
            })
    }

    async function setnewRebaserate() {
        const options = {
            contractAddress: ContractAddresses.arceus,
            functionName: 'setRebaseRate',
            chain: window.chain,
            abi: ArceusAbi,
            params: {
                _rate: String(dashData.newRebaserate)
            }
        }

        await Moralis.executeFunction(options)
            .then(response => response && window.location.reload())
            .catch(error => {
                showMessage({
                    type: 'error',
                    content: <span>{error.reason}</span>,
                    solution: null
                })
            })
    }


    async function toggleSwapBack() {
        const options = {
            contractAddress: ContractAddresses.arceus,
            functionName: 'setSwapEnabled',
            chain: window.chain,
            abi: ArceusAbi,
            params: {
                _flag: !dashData.swapState
            }
        }

        await Moralis.executeFunction(options)
            .then(response => response && window.location.reload())
            .catch(error => {
                showMessage({
                    type: 'error',
                    content: <span>{error.reason}</span>,
                    solution: null
                })
            })

    }

    async function togglePartnershipState() {
        const options = {
            contractAddress: ContractAddresses.arceus,
            functionName: 'setPartnerEnabled',
            chain: window.chain,
            abi: ArceusAbi,
            params: {
                _flag: !dashData.parnershipState
            }
        }

        await Moralis.executeFunction(options)
            .then(response => response && window.location.reload())
            .catch(error => {
                showMessage({
                    type: 'error',
                    content: <span>{error.reason}</span>,
                    solution: null
                })
            })

    }


    function handlenewRebaserate(event) {
        setDashData(data => data = { ...data, newRebaserate: event.target.value })
    }


    function handleCopyContract() {
        const copy = navigator.clipboard.writeText(ContractAddresses.arceus)
        if (copy) {
            showMessage({
                type: 'success',
                content: <span>Contract Address Copied..</span>,
                solution: null
            })
        }
    }

    function handlepartnerAddressChange(event) {
        setDashData(data => data = {
            ...data,
            partnerAddress: event.target.value
        })
    }

    function handlePartnerSymbolChange(event) {
        setDashData(data => data = {
            ...data,
            partnerSymbol: event.target.value
        })
    }


    async function addPartner() {
        const options = {
            contractAddress: ContractAddresses.arceus,
            functionName: 'addPartner',
            chain: window.chain,
            abi: ArceusAbi,
            params: {
                Partner: dashData.partnerAddress,
                Symbol: dashData.partnerSymbol
            }
        }

        await Moralis.executeFunction(options)
            .then(response => response && window.location.reload())
            .catch(error => {
                showMessage({
                    type: 'error',
                    content: <span>{error.reason}</span>,
                    solution: null
                })
            })
    }

    async function removePartner(event) {
        const address = event.target.name ? event.target.name : dashData.partnerAddress
        const options = {
            contractAddress: ContractAddresses.arceus,
            functionName: 'removePartner',
            chain: window.chain,
            abi: ArceusAbi,
            params: {
                Partner: address,
            }
        }

        await Moralis.executeFunction(options)
            .then(response => response && window.location.reload())
            .catch(error => {
                showMessage({
                    type: 'error',
                    content: <span>{error.reason}</span>,
                    solution: null
                })
            })
    }

    async function getAllPartners() {
        const options = {
            contractAddress: ContractAddresses.arceus,
            functionName: 'getAllPartners',
            chain: window.chain,
            abi: ArceusAbi,
            params: {}
        }

        await Moralis.executeFunction(options)
            .then(response => {
                setDashData(data => data = {
                    ...data,
                    allPartners: response
                })
            })
            .catch(error => {
                showMessage({
                    type: 'error',
                    content: <span>{error.reason}</span>,
                    solution: null
                })
            })
    }

    async function handleReferreeAddressChange(event) {
        if (event.target.value != '') {
            setDashData(data => data = {
                ...data,
                referralEarnings: (<div className="lds-ripple"><div></div><div></div></div>)
            })
        }
        await ArceusContract.getRefEarnings(event.target.value)
            .then(response => {
                setDashData(data => data = {
                    ...data,
                    referralEarnings: formatUnits(String(response), '5')
                })
            })
    }

    async function setNewPartnerFee() {
        const options = {
            contractAddress: ContractAddresses.arceus,
            functionName: 'setMinPartnerBalance',
            chain: window.chain,
            abi: ArceusAbi,
            params: {
                _amount: Moralis.Units.Token(String(dashData.newPartnerMinBalance), '5')
            }
        }

        await Moralis.executeFunction(options)
            .then(response => {
                window.location.reload()
            })
            .catch(error => {
                showMessage({
                    type: 'error',
                    content: <span>{error.reason}</span>,
                    solution: null
                })
            })
    }

    async function burntokens() {
        const options = {
            contractAddress: ContractAddresses.arceus,
            functionName: 'burnArceus',
            chain: window.chain,
            abi: ArceusAbi,
            params: {
                amount: Moralis.Units.Token(String(dashData.amounttokenstoBurn), '5')
            }
        }

        await Moralis.executeFunction(options)
            .then(response => {
                window.location.reload()
            })
            .catch(error => {
                showMessage({
                    type: 'error',
                    content: <span>{error.data.message}</span>,
                    solution: null
                })
            })
    }


    const RebaseAndSupplyInfo = (
        <motion.div
            initial={{ opacity: 0, y: -20 }}
            whileInView={{ opacity: 1, y: 0 , transition: 2}}
            viewport={{ once: false }}
            className="dash-count-down stand-alone left">
            <div className="card-main first no-gray">
                <h4 className="h4-headline">Total Supply</h4>
                <div className="card-content">
                    {dashData.totalSupply}
                </div>
                <GetIcon icon={`${dashData.allLoaded ? 'arcfavi' : 'spinner'}`} classname={`m-none right-icon-big ${dashData.allLoaded ? '' : 'spinner'}`} />
            </div>

            <div className="left-inner">
                <ul className="ico-details">
                    <li className="ico-list">
                        <span className="t-span-item flex-nowrap space-between">
                            <i>Current Rate</i>
                            <i>{dashData.currentRebaseRate / 1e5}%</i>
                        </span>
                        <span className="t-span-item flex-nowrap space-between">
                            <i>25Minutes Rate</i>
                            <i>{dashData.currentRebaseRate / 1e5}%</i>
                        </span>
                        <span className="t-span-item flex-nowrap space-between">
                            <i>1Day Rate</i>
                            <i>Up to {dashData.currentRebaseRate / 1e5 * 100}%</i>
                        </span>
                        <span className="t-span-item flex-nowrap space-between">
                            <i>Compounding Rate</i>
                            <i>{56}x Daily</i>
                        </span>
                    </li>
                </ul>
            </div>

            <div className="flex-column last">
                <h4 className="h4-headline">Arceus Contract</h4>
                <div className="flex-nowrap space-between">
                    <a className="primary-btn middle-all flex-nowrap no-shadow no-gray"
                        target={'_blank'}
                        referrerPolicy={'no-referrer'}
                        href={window.explorer + '/address/' + ContractAddresses.arceus}>
                        <GetIcon icon={'externallink'} classname='m-none' /> {' Contract'}
                    </a>

                    <button
                        className="primary-btn middle-all flex-nowrap no-shadow no-gray"
                        onClick={handleCopyContract} >
                        <GetIcon icon={'arcfavi'} /> {`Copy Address`}
                    </button>
                </div>
            </div>

        </motion.div>
    )


    const TaxCollectos = (
        <motion.div
            initial={{ opacity: 0, y: -20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: false }}
            className="dash-count-down stand-alone right">
            <div className="card-main">
                <h4 className="h4-headline">Insurance Fund</h4>
                <div className="card-content flex-nowrap no-gray">
                    <GetIcon icon={'usd'} />
                    {Number(dashData.insuranceFundValue).toFixed(3)}
                    <GetIcon icon={'growingmoney'} classname='m-none right-icon-big' />
                </div>
            </div>

            <div className="card-main">
                <h4 className="h4-headline">Treasury Fund</h4>
                <div className="card-content flex-nowrap no-gray">
                    <GetIcon icon={'usd'} />
                    {Number(dashData.treasuryFundValue).toFixed(3)}
                    <GetIcon icon={'usd'} classname='m-none right-icon-big' />
                </div>
            </div>

            <div className="card-main">
                <h4 className="h4-headline">Firepit Supply</h4>
                <div className="card-content flex-nowrap  no-gray">
                    <GetIcon icon={'usd'} />
                    {Number(formatUnits(dashData.firePitWallet, '5') * dashData.marketPrice).toFixed(3)}
                    <GetIcon icon={'hexburner'} classname='m-none right-icon-big' />
                </div>
            </div>
        </motion.div>
    )


    const Tokenprice = (
        <div className="card-main">
            <h4 className="h4-headline flex-nowrap space-between middle-all">
                ARC Price
                <a href="/@/swap"
                    className="primary-btn np" >
                    {`Buy Now`}
                </a>
            </h4>
            <div className="card-content flex-nowrap">
                {/* <GetIcon icon={'usd'} /> */}
                $ {dashData.marketPrice}
            </div>
        </div>
    )

    const TokenValues = (
        // <div className="dash-count-down stand-alone left p-none">
        <motion.ul
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: false }}
            className='t-history-ul  '>
            <GetIcon icon={'centralizednetwork'} classname='token-val-bg' />
            {/* <li className="t-hostory-li">
                <span className="t-span-item">Name</span>
                <span className="t-span-item">ARC</span>
                <span className="t-span-item">USD</span>
            </li> */}

            <li className="t-hostory-li">
                <span className="t-span-item no-padding"> Circulating Supply </span>
                <span className="t-span-item">{numFormatter(Number(dashData.circulatingSupply).toFixed(3))} </span>
                <span className="t-span-item">$ {numberWithCommas(Number(dashData.circulatingSupply * dashData.marketPrice).toFixed(2))} </span>
            </li>

            <li className="t-hostory-li">
                <span className="t-span-item no-padding">Pool Value </span>
                <span className="t-span-item"></span>
                <span className="t-span-item">$ {numberWithCommas(Number(dashData.ArceuspoolValue).toFixed(2))} </span>
            </li>

            <li className="t-hostory-li">
                <span className="t-span-item no-padding">Market Cap </span>
                <span className="t-span-item"></span>
                <span className="t-span-item">$ {numberWithCommas(Number(dashData.marketCap).toFixed(2))} </span>
            </li>

            <li className="t-hostory-li">
                <span className="t-span-item no-padding"> Arceus Burnt </span>
                <span className="t-span-item"> {numFormatter(Number(formatUnits(dashData.firePitWallet, '5')).toFixed(3))} </span>
                <span className="t-span-item">$ {numberWithCommas(Number(formatUnits(dashData.firePitWallet, '5') * dashData.marketPrice).toFixed(3))} </span>
            </li>

            {/* <li className="t-hostory-li">
                <div className="flex-nowrap space-between">
                    <GetIcon icon={'bogged'} />
                    <a className="primary-btn middle-all flex-nowrap no-shadow no-gray"
                        target={'_blank'}
                        referrerPolicy={'no-referrer'}
                        href={'/'}>
                        {`Buy Arc.`}
                    </a>
                </div>
            </li> */}

        </motion.ul>
        // </div>
    )

    return (
        <motion.section
            initial={{ opacity: 0, y: -100 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -100 }}
            className="section">

            <div className='center-element padding-1rem'>
                <div className="counter-wrapper">
                    <div className="cards-wrapper">

                        {wWidth > 800 && TokenValues}
                        {wWidth > 800 && RebaseAndSupplyInfo}

                        {wWidth <= 800 && RebaseAndSupplyInfo}
                        {wWidth <= 800 && TokenValues}


                        {TaxCollectos}
 
                      


                        <div className="min-social-nav no-gray">
                            {/* <h3 className="h3-headline">Stay With Us 👨‍👩‍👧‍👦</h3> */}
                            <SocialLinks />
                        </div>


                        {
                            dashData.isAdmin === 'true' && <div className="admin-actions">
                                <h3 className="h3-headline">Hi Admin, {dashData.dayTimeGreeting}</h3>
                                <div className="cards-wrapper">

                                    <div className="button-input-wrapper">
                                        <button
                                            className={`primary-btn  ${dashData.autoRebaseState === true ? 'active' : 'inactive'}`}
                                            onClick={toggleAutoRebase} >
                                            {'Auto Rebase: is '} {dashData.autoRebaseState === true ? 'On' : 'Off'}
                                        </button>
                                    </div>

                                    <div className='button-input-wrapper'>
                                        <button
                                            className={`primary-btn  ${dashData.autoLiquidityState === true ? 'active' : 'inactive'}`}
                                            onClick={toggleAutoAddliquidity} >
                                            {'Auto Add Liquidity: is '} {dashData.autoLiquidityState === true ? 'On' : 'Off'}
                                        </button>
                                    </div>


                                    <div className='button-input-wrapper'>
                                        <button
                                            className={`primary-btn  ${dashData.parnershipState === true ? 'active' : 'inactive'}`}
                                            onClick={togglePartnershipState} >
                                            {'Allow Partnership: is '} {dashData.parnershipState === true ? 'On' : 'Off'}
                                        </button>
                                    </div>


                                    <div className="button-input-wrapper">
                                        <button
                                            className={`primary-btn  ${dashData.swapState === true ? 'active' : 'inactive'}`}
                                            onClick={toggleSwapBack} >
                                            {'Swap Back: is '} {dashData.swapState === true ? 'On' : 'Off'}
                                        </button>
                                    </div>

                                    <div className="button-input-wrapper">
                                        <button
                                            className="primary-btn"
                                            onClick={withdrawAllETH} >
                                            {'Withdraw All BNB'}
                                        </button>
                                    </div>

                                    <div className="button-input-wrapper">
                                        <button
                                            className="primary-btn"
                                            onClick={withdrawAllToTreasury} >
                                            {'Withdraw All To Treasury'}
                                        </button>
                                    </div>


                                    <div className="button-input-wrapper dash-tabs">

                                        <input
                                            className="swap-int-input"
                                            placeholder={ContractAddresses.arceus}
                                            value={dashData.tokenToWithdrawAddress}
                                            onInput={handleTokenToWithdraw}
                                        />

                                        <button
                                            className="primary-btn"
                                            onClick={withdrawERC20Token} >
                                            {dashData.tokenToWithdrawBalance}
                                        </button>

                                    </div>


                                    <div className="button-input-wrapper dash-tabs">

                                        <button
                                            className="primary-btn" disabled>
                                            {'Current Is: ' + dashData.currentMinPartnerbalance}
                                        </button>

                                        <input
                                            className="swap-int-input"
                                            placeholder={'enter min amount, 1 = 1'}
                                            onInput={(event) => setDashData(data => data = { ...data, newPartnerMinBalance: event.target.value })}
                                        />

                                        <button
                                            className="primary-btn"
                                            onClick={setNewPartnerFee} >
                                            {'Set Min Partner Balance'}
                                        </button>
                                    </div>

                                    <div className="button-input-wrapper dash-tabs">


                                        <input
                                            className="swap-int-input"
                                            placeholder={'enter amount,  100 = 100'}
                                            onInput={(event) => setDashData(data => data = { ...data, amounttokenstoBurn: event.target.value })}
                                        />

                                        <button
                                            className="primary-btn"
                                            onClick={burntokens} >
                                            {'Burn Tokens'}
                                        </button>
                                    </div>


                                    <div className="button-input-wrapper dash-tabs space-between">

                                        <input
                                            className="swap-int-input"
                                            placeholder={ContractAddresses.arceus}
                                            onInput={handlepartnerAddressChange}
                                        />

                                        <input
                                            className="swap-int-input"
                                            placeholder={'ARC'}
                                            onInput={handlePartnerSymbolChange}
                                        />

                                        <button
                                            className="primary-btn"
                                            onClick={addPartner} >
                                            {'Add Partner'}
                                        </button>

                                    </div>

                                    <div className="button-input-wrapper dash-tabs space-between">
                                        <input
                                            // contentEditable
                                            className="swap-int-input editable"
                                            value={dashData.newRebaserate}
                                            placeholder={dashData.currentRebaseRate}
                                            onChange={handlenewRebaserate}
                                        />&nbsp; &nbsp;%&nbsp;&nbsp;

                                        <button
                                            className="primary-btn"
                                            onClick={setnewRebaserate} >
                                            {`Set rebase rate`}
                                        </button>

                                    </div>

                                    <div className="button-input-wrapper dash-tabs space-between">

                                        <input
                                            className="swap-int-input"
                                            placeholder={dashData.refereeAddress}
                                            onInput={handleReferreeAddressChange}
                                        />
                                        &nbsp;&nbsp;&nbsp;
                                        <span>
                                            {dashData.referralEarnings ? dashData.referralEarnings : ''}
                                        </span>
                                    </div>



                                    <details className="no-shadow w-full ">
                                        <summary onClick={getAllPartners} className="flex-nowrap space-between">
                                            <h3 className="h3-headline summary-notation flex-nowrap no-gray">
                                                <GetIcon icon={'guest_male'} classname='icon-size-21' />
                                                &nbsp;
                                                Get all partners
                                            </h3>
                                        </summary>

                                        {
                                            dashData.allPartners[0] != null ?
                                                <ul className='t-history-ul alone'>

                                                    <li className="t-hostory-li">
                                                        <span className="t-span-item">Symbol</span>

                                                        <span className="t-span-item">Join Date</span>
                                                        <span className="t-span-item"> Partner Address </span>
                                                        <span className="t-span-item">Admin Actions</span>
                                                    </li>
                                                    {console.info(dashData.allPartners.length)}
                                                    {dashData.allPartners.length && dashData.allPartners.map(
                                                        partner => {
                                                            if (partner.account != '0x0000000000000000000000000000000000000000') {
                                                                return (
                                                                    <li className="t-hostory-li">
                                                                        <span className="t-span-item">{partner.symbol}</span>

                                                                        <span className="t-span-item">{getTime(partner.timeStamp).slice(0, 17)}</span>
                                                                        <span className="t-span-item">
                                                                            <a href={window.explorer + '/address/' + partner.account} target={'_blank'} className='t-h-link'>
                                                                                {partner.account}
                                                                            </a>
                                                                        </span>
                                                                        <span className="t-span-item">
                                                                            <button
                                                                                className={`primary-btn  ${dashData.swapState === true ? 'active' : 'inactive'}`}
                                                                                name={partner.account}
                                                                                onClick={removePartner} >
                                                                                Remove {partner.symbol}
                                                                            </button>
                                                                        </span>
                                                                    </li>
                                                                )
                                                            }
                                                        })
                                                    }
                                                </ul> : (<span style={{ 'padding': '1rem' }} className="font-16 iserror">No Partners Yet.</span>)
                                        }

                                    </details>
                                </div>
                            </div>
                        }
                    </div>
                </div>
            </div>
        </motion.section>
    )
}

export default Dashboard