import { GetIcon } from "../icons/ExportIcon"
import { CountDownSeconds, CountDownTime } from "../reuseables/CountDown"
import { numberWithCommas, numFormatter } from "../reuseables/Numbers"
import { BigNumber, } from "ethers/lib/ethers"
import { formatUnits } from "ethers/lib/utils"
import { useEffect, useState } from "react"
import ArceusAbi from '../constants/ArceusAbi.json'
import ContractAddresses from "../constants/ContractAddresses"
import { useWeb3ExecuteFunction } from "react-moralis"
import { useMoralis } from "react-moralis"
import { FetchTokenPriceBUSD } from "../reuseables/FetchTokenPrice"
import { useNavigate } from "react-router-dom"

function ClaimRewards({ params }) {

    const { days, hours, mins, secs } = CountDownTime('84600')
    const { Moralis } = useMoralis()
    const navigate = useNavigate()

    const { data, error, fetch, isFetching, isLoading } = useWeb3ExecuteFunction({
        contractAddress: ContractAddresses.arceus,
        functionName: "claimTokens",
        abi: ArceusAbi,
        params: {}
    })

    const {
        login,
        address,
        isAuthenticated,
        isAuthenticating,
        ArceusContract,
        dataLoading,
        showMessage, isCorrectNetwork, switchNetwork, motion } = params

    const [dashData, setDashData] = useState({
        myBalance: 0,
        newClaimTime: dataLoading,
        allRewards: 0,
        claimErr: false,
        canClaimNow: false,
        marketPrice: 0,
        nextClaimAmount: 0,
        referralEarning: 0,
        claimButtonDisabled: true,
    })

    useEffect(() => {
        let session_done = true
        let countFrom = 0
        setInterval(async () => {
            if (window.address != undefined) {
                if (countFrom <= 0) {
                    if (session_done == true) {
                        session_done = false
                        setDashData(data => data = {
                            ...data,
                            newClaimTime: { hours: '00', minutes: '00', seconds: '00' }
                        })
                        await Promise.all([
                            ArceusContract.balanceOf(window.address),
                            FetchTokenPriceBUSD(0),
                            ArceusContract.getAccountInfoMate(window.address),
                            ArceusContract.claimingInterval(),
                            ArceusContract.minBalance()
                        ])
                            .then(response => {
                                countFrom = countFrom <= 0 ? Number(response[3]) - Number(response[2].nextTime) : 0
                                setDashData(data => data = {
                                    ...data,
                                    marketPrice: response[1],
                                    myBalance: formatUnits(String(response[0]), '5'),
                                    allRewards: formatUnits(String(response[2].earnedSoFar), '5'),
                                    referralEarning: formatUnits(String(response[2].EarnedFromRef), '5'),
                                    nextClaimAmount: 'CLAIM ' + numFormatter(formatUnits(response[2].amount, '5')),
                                    nextClaimErr: false,
                                    claimButtonDisabled: false,
                                    canClaimNow: true
                                })
                                if (String(response[2].amount) == 0) {
                                    setDashData(data => data = {
                                        ...data,
                                        nextClaimErr: true,
                                        claimButtonDisabled: true,
                                        canClaimNow: false,
                                        nextClaimAmount: 'HODL (ARC ' + formatUnits(String(response[4]), '5') + ') To Qualify'
                                    })
                                }
                            })
                        session_done = true
                    }
                } else {
                    setDashData(data => data = {
                        ...data,
                        newClaimTime: CountDownSeconds(countFrom),
                        canClaimNow: false,
                        claimButtonDisabled: true,
                        nextClaimAmount: "Waiting... 🤲"
                    })
                    countFrom -= 1
                }

            }

            else {
                setDashData(data => data = {
                    myBalance: '---',
                    nextClaimTime: '---',
                    allRewards: '---',
                    nextClaimAmount: 'no wallet detected.',
                })
            }
        }, 1000)
    }, [])


    const countDownTime = (
        dashData.newClaimTime != undefined ?
            <div className="flex-nowrap">
                <div className="counter-digit">{dashData.newClaimTime.hours}:</div>
                <div className="counter-digit">{dashData.newClaimTime.minutes}:</div>
                <div className="counter-digit">{dashData.newClaimTime.seconds}</div>
            </div>
            : dashData.newClaimTime
    )

    async function claimTokens() {
        const chainid = await window.ethereum.request({ method: 'eth_chainId' })
        if (chainid != window.chain) {
            showMessage({
                type: 'error',
                content: 'You Are On the Wrong Network.',
                solution: switchNetwork
            })
        } else {
            setDashData(data => data = {
                ...data,
                claimButtonDisabled: true
            })
            await Moralis.enableWeb3()
            await fetch()
            await data.data.wait()
                .then(done => setDashData(data => data = { ...data, waitingConfirmation: done }))
            // window.location.reload()
        }
    }

    return (
        <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0, transition: { delay: .2 } }}
            viewport={{ once: false }}

            className="claim-tokens-wrapper acc-list">
            {/* <motion.p
                initial={{ opacity: 0, x: 100 }}
                whileInView={{ opacity: 1, x: 0, transition: { delay: .2 } }}
                viewport={{ once: false }}
                className="font-13 text-paragraph">
                The Arceus protocol rewards HODLERS, <br />
                HODLERS who bought and HODLS Atleast 500 ARC in they wallet.<br />
                Eligible account can claim they reward every 24 hours fro each wallet.<br />
                For unknown reason: it's free.
            </motion.p> */}

            <motion.div
                initial={{ opacity: 0, x: -100 }}
                whileInView={{ opacity: 1, x: 0, transition: { delay: .2 } }}
                viewport={{ once: false }}

                className="cards-wrapper claim-tokens-inner ">
                <motion.div 
                    className="card-main">
                    <h4 className="h4-headline">All Time Rewards?</h4>
                    <div className="card-content">
                        ARC {numFormatter(dashData.allRewards)}
                    </div>
                    <div className="card-content">$ {numberWithCommas(Number(dashData.allRewards * dashData.marketPrice).toFixed(3))}</div>
                </motion.div>

                <motion.div 
                    className="card-main">
                    <h4 className="h4-headline">Earned From Referrals?</h4>
                    <div className="card-content">for partners:  <a href="" className="font-13 active padding-dot2em">Join</a></div>
                    <div className="card-content">$ {numberWithCommas(Number(dashData.referralEarning * dashData.marketPrice).toFixed(3))}</div>
                </motion.div>

                <motion.div className="card-main">
                    <h4 className="h4-headline">Current Balance?</h4>
                    <div className="card-content flex-nowrap">ARC {numFormatter(dashData.myBalance)}</div>
                    <div className="card-content">$ {numberWithCommas(Number(dashData.myBalance * dashData.marketPrice).toFixed(3))}</div>
                </motion.div>

                <div className="card-main w-full no-bg no-shadow ">
                    <div className="card-content">
                        {countDownTime}
                        <div className="button-input-wrapper">
                            <button
                                className={`primary-btn ${isAuthenticated && !isCorrectNetwork ? 'iserror' : isLoading ? 'inactive' : 'active'} `}
                                disabled={dashData.claimButtonDisabled || isLoading || isFetching || isAuthenticating ? true : false}
                                onClick={isAuthenticated && !isCorrectNetwork ? switchNetwork : isAuthenticated ? claimTokens : login} >
                                {
                                    isAuthenticated && !isCorrectNetwork ? 'Switch Network'
                                        : isLoading ? 'Loading...'
                                            : isAuthenticating ? 'Authenticating...'
                                                : error ? error.message
                                                    : dashData.waitingConfirmation ? 'Waiting Confirmation...'
                                                        : isAuthenticated ? dashData.nextClaimAmount
                                                            : 'Connect Wallet'
                                }
                            </button>
                            {/* &nbsp;&nbsp; */}
                            <button
                                onClick={() => navigate('/@/swap')}
                                className="primary-btn green">
                                Buy ARC
                            </button>
                        </div>
                    </div>
                </div>

            </motion.div>
        </motion.div>
    )
}


export default ClaimRewards