import { useParams } from "react-router-dom"
import { useState, useEffect } from 'react'
import { GetIcon } from "../icons/ExportIcon"
import { ethers } from "ethers"
import { useMoralis } from "react-moralis"
import ArceusAbi from '../constants/ArceusAbi.json'
import ContractAddresses from "../constants/ContractAddresses"
function ReferralEngagement({ params }) {
    const { partner } = useParams()
    const { Moralis } = useMoralis()
    const { showMessage, isAuthenticated, login, isCorrectNetwork, switchNetwork, ArceusContract } = params

    useEffect(() => {
        const correctAddress = ethers.utils.isAddress(partner)

        if (correctAddress) {
            const { ethereum } = window
            async function checkRef(){
                if (ethereum != undefined) {
                    const address = ethereum.selectedAddress
                    await ArceusContract.getReferralsByAddress(partner)
                        .then(accounts => {
                            if (accounts.lenght === undefined){
                                toggleModal() 
                                return
                            }
                            accounts.map(
                                account => {
                                    if (String(account).toLocaleLowerCase() === String(address).toLocaleLowerCase()) {
                                        showMessage({
                                            type: 'error',
                                            content: <span>{'Referee has already referred you.'} <br />You will be redirected in 3Secs.</span>,
                                            solution: null
                                        })
                                        setTimeout(() => {
                                            window.location.href = '/@/dashboard'
                                        }, 3000);
                                    } else { toggleModal() }
                                }
                            )
                        })
                } else { toggleModal() }
            }
            checkRef()
        }
        else {
            showMessage({
                type: 'error',
                content: <span>{partner.slice(1, 4) + '...' + partner.slice(-4)} Is not A Valid Eth Account.</span>,
                solution: null
            })
            setTimeout(() => {
                window.location.href = '/@/dashboard'
            }, 10000);
        }
    }, [])

    const [modalVisible, setModalVisible] = useState(false)

    function toggleModal(modalState) {
        setModalVisible(visibility => visibility = modalState != undefined ? modalState : !visibility)
        if (modalState != undefined) {
            window.location.href = '/@/dashboard'
        }
    }

    async function confimReferral(params) {
        const options = {
            functionName: 'addReferral',
            contractAddress: ContractAddresses.arceus,
            abi: ArceusAbi,
            chain: window.chain,
            params: {
                _ref: window.address,
                _referee: partner
            }
        }

        await Moralis.executeFunction(options)
            .then(async response => {
                await response.wait()
                    .then(done => {
                        showMessage({
                            type: 'success',
                            content: <span>{'Referral confirmed ' + done.confirmations}</span>,
                            solution: null
                        })
                        setTimeout(() => {
                            window.location.href = '/@/dashboard'
                        }, 3000);
                    })
            })
            .catch(error => {
                showMessage({
                    type: 'error',
                    content: <span>{error.reason}</span>,
                    solution: null
                })
            })
    }


    if (modalVisible === true) {
        return (
            <div className="referral-modal">
                <modal className='modal'>
                    <h4 className="h4-headline flex-nowrap space-between">
                        <span>Hey there, <br />Thanks for your Interest in Arceus Project 😍😋</span>
                        <GetIcon icon={'close'} trigger={() => toggleModal(false)} classname={''} />
                    </h4>
                    <p className="font-13 text-paragraph">
                        You have been referred by: {partner.slice(0, 4) + '***' + partner.slice(-4)}
                    </p>
                    <div className="button-input-wrapper w-full">
                        <button
                            className={`primary-btn ${isAuthenticated && !isCorrectNetwork ? 'iserror' : isAuthenticated ? 'active' : 'inactive'} w-full`}
                            onClick={isAuthenticated && !isCorrectNetwork ? switchNetwork : isAuthenticated ? confimReferral : login} >
                            {isAuthenticated && !isCorrectNetwork ? 'Switch newtwork' : isAuthenticated ? 'Confirm Referral' : 'Connect Wallet To Proceed'}
                        </button>
                    </div>
                </modal>
            </div>
        )
    }
}

export default ReferralEngagement