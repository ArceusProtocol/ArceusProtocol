import { Contract, ethers, utils } from "ethers";

async function PooReserves(GetImpactInfo) {

    const { poolAddress, assetFrom, assetTo, amountReceied, amountPayin } = GetImpactInfo; // CAKE-USDT

    const poolContract = new Contract(
        poolAddress,
        ['function getReserves() public view returns (uint112 _reserve0, uint112 _reserve1, uint32 _blockTimestampLast)'],
        window.provider
    );
    let Impact = 0

    let reserve0, reserve1
    await poolContract.getReserves()
        .then((reserves) => {
            let reserve_a_initial = parseFloat(utils.formatUnits(reserves._reserve0));
            let reserve_b_initial = parseFloat(utils.formatEther(reserves._reserve1));
            reserve0 = reserve_a_initial
            reserve1 = reserve_b_initial


            const fee = 0.2;
            let max_price_impact = 0.1;

            let amount_traded_cake = reserve_a_initial * max_price_impact / ((1 - max_price_impact) * (1 - fee));
            let amount_traded_usdt = reserve_b_initial * max_price_impact / ((1 - max_price_impact) * (1 - fee));

            let amountInCAKE = amountReceied * (1 - fee);
            let amountInUSDT = amountPayin * (1 - fee);

            let price_impact_trade_cake = amountInCAKE / (reserve_a_initial + amountInCAKE);
            let price_impact_trade_usdt = amountInUSDT / (reserve_b_initial + amountInUSDT);

            Impact = (price_impact_trade_usdt * 100)
            Impact = Impact > 0.01 ? Number(Impact).toFixed(2) : Impact < 0.01 ? '< 0.01 ' : Number(Impact)

        }).catch(error => Impact = error.message);
    return Impact;

}

export default PooReserves