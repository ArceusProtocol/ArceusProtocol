import { GetIcon } from "./icons/ExportIcon"
import { TokenS } from "./tokens"

function TokensList({ params }) {

    const { toggle, show, side, selectToken, dashData, isAuthenticated, isAuthenticating, login, motion, useDragControls } = params
    const controls = useDragControls()
    const TOKENS = []

    for (const key in TokenS.tokens) {
        const element = TokenS.tokens[key];
        TOKENS.push(
            <li className="tokens-li flex-nowrap space-between"
                onClick={() => selectToken({ address: element.address, decimals: element.decimals, symbol: element.symbol, logoURI: element.logoURI, side: side })}>
                <div className="tokens-main  flex-nowrap">
                    <GetIcon icon={element.logoURI} />
                    <div className="tokens-name flex-column left">
                        <i className="font-13">{element.symbol}</i>
                        <span className="font-13">{element.name}</span>
                    </div>
                </div>

                <div className="tokens-balance flex-column">
                    <div className="card-content flex-column ">
                        <i onClick={isAuthenticated ? '' : login}>
                            {isAuthenticated ? '0' : isAuthenticating ? 'loading' : 'login'}
                        </i>
                    </div>
                </div>
            </li>
        )
    }

    console.log(show)

    if (show === true) {
        return (
            <motion.div

                initial={{ y: 100 }}
                animate={{ y: 0 }}
                exit={{ y: 100 }}

                className="tokens-list-wrapper">
                <div className="tokens-list-inner">
                    <div className="flex-nowrap space-between padding-1rem w-full">
                        <h4 className="h4-healine">{side}</h4>
                        <GetIcon trigger={() => toggle(null, false)} icon={'close'} />
                    </div>
                    <ul className="tokens-ul">

                        <div className="tokens-li flex-nowrap space-between level-ident">
                            <i className="font-13">Token name</i>
                            <i className="font-13">Balance</i>
                        </div>

                        {TOKENS}

                        <li className="tokens-li flex-nowrap space-between">
                            <span style={{ fontSize: '10px' }}>More Coming Soon...😎</span>
                        </li>
                    </ul>
                </div>
            </motion.div>
        )
    }
}

export default TokensList