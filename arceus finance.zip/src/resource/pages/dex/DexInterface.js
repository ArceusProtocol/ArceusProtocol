import { useParams } from "react-router-dom"
import './dex.css'
import { useEffect, useState } from "react"
import { GetIcon } from "../../icons/ExportIcon"
import TokensList from "./TokensList"
import Modal from "../../reuseables/Modal"
import { TokenS } from "./tokens"
import { useMoralis, useWeb3ExecuteFunction } from "react-moralis"
import ContractAddresses from "../../constants/ContractAddresses"
import PancakeAbi from '../../constants/PancakeRouterAbi.json'
import AbiFunctions from '../../constants/ArceusAbiFunctions'
import { ethers } from 'ethers'
import PooReserves from "./PooReserves"
function DexInterface({ params }) {

    const { login,
        isAuthenticated,
        isAuthenticating,
        tokenFrom,
        tokenTo,
        motion,
        showMessage,
        isCorrectNetwork,
        switchNetwork,
        useDragControls
    } = params

    const { enableWeb3, Moralis } = useMoralis()
    const [wWidth, setwWidth] = useState(window.innerWidth)

    const { data, error, fetch, isFetching, isLoading } = useWeb3ExecuteFunction({
        contractAddress: ContractAddresses.arceus,
        functionName: "claimTokens",
        abi: PancakeAbi,
        params: {}
    })


    useEffect(() => window.addEventListener('resize', () => setwWidth(window.innerWidth)))
    const [dashData, setDataData] = useState({
        listSide: null,
        pay: { address: 'null' },
        receive: { address: 'null' },
        amountTo: '0.00',
        amountFrom: '0.00',
        tokensListShow: false,
        floatPlaceHolder: '0.00',
        tokenFromRate: '0.00',
        tokenFrombalance: '0.00',
        tokenToBalance: '0.00',
        thereIsPriceNow: false,
        priceImpact: 0,
        showModal: false,
        untouchedDeadline: new Date().getTime(),
        finalDeadLine: 0,
        impacA: 0,
        impactB: 0,
        useSwapFunction: 'swapExactTokensForETH',
        tokensOrNative: 'erc20'
    })


    // const swapOptions = {
    //     functionName: dashData.useSwapFunction,
    //     contractAddress: ContractAddresses.pancakeRouter,
    //     abi: PancakeAbi,
    //     type: dashData.tokensOrNative,
    //     amount: Moralis.Units.Token(dashData.amountFrom, dashData.pay.decimals),
    //     chain: window.chain,
    //     params: {
    //         amountIn: Moralis.Units.Token("10", "5"),
    //         amountOutMin: dashData['amountTo'],
    //         path: [dashData.pay['address'], dashData.receive['address']],
    //         to: window.address != undefined && window.address,
    //         deadline: '12345678909876'
    //     }
    // }

    // const SwapEthForTokenOptions = {
    //     functionName: 'swapExactETHForTokensSupportingFeeOnTransferTokens',
    //     contractAddress: ContractAddresses.pancakeRouter,
    //     abi: PancakeAbi,
    //     type: 'native',
    //     msgValue: Moralis.Units.ETH("10"),
    //     chain: 'bsc',
    //     params: {
    //         amountOutMin: Moralis.Units.Token("10", '5'),
    //         amountOutMin: '0',
    //         path: [dashData.pay['address'], dashData.receive['address']],
    //         to: window.address != undefined && window.address,
    //         deadline: '12345678909876'
    //     }
    // }

    async function SwapTokens() {
        // await enableWeb3()
        // const message = await Moralis.executeFunction(swapOptions)
        //     .then(async hash => {
        //         await hash.wait()
        //             .then(done => showMessage({
        //                 type: 'success',
        //                 content: <span>Confirmations: {String(done.confirmations)}</span>,
        //                 solution: window.explorer + `/tx/${done.hash}`
        //             })
        //             )
        //     })
        //     .catch(error => {
        //         showMessage({
        //             type: 'success',
        //             content: error.message,
        //             solution: null
        //         })
        //     })
    }


    useEffect(() => {
        for (const key in TokenS.tokens) {
            const element = TokenS.tokens[key];
            if (element.symbol.toUpperCase() === tokenFrom.toUpperCase()) {
                setDataData(data => data = { ...data, pay: element })
            }
            else if (element.symbol.toUpperCase() === tokenTo.toUpperCase()) {
                setDataData(data => data = { ...data, receive: element })
            }
        }
    }, [])

    function estimateGas() {
        // Gas Limit * Gwei amount / Gwei Denomination
    }


    function showTokensListSide(side, toggle) {
        setDataData(data => data = { ...data, listSide: side, tokensListShow: toggle })
    }

    function setNewTrade(token) {
        setDataData(data => data = { ...data, tokensListShow: false })
        const { side } = token;
        (side === 'pay') && setDataData(pairs => pairs = { ...pairs, pay: token });
        (side === 'receive') && setDataData(pairs => pairs = { ...pairs, receive: token });
    }

    function ShowDexSettings(state) {
        setDataData(data => data = {
            ...data, showModal: state
        })
    }

    const ModalParams = {
        show: dashData.showModal,
        toggle: ShowDexSettings,
        content: '',
        type: 'dexsettings',
        headline: 'Settings'
    }

    const TokenSideParams = {
        show: dashData.tokensListShow,
        toggle: showTokensListSide,
        side: dashData.listSide,
        selectToken: setNewTrade,
        isAuthenticated: isAuthenticated,
        login: login,
        isAuthenticating: isAuthenticating,
        motion: motion,
        useDragControls: useDragControls
    }

    async function getAmountOutput(token) {
        const { PanCakeRouterContract } = window
        let { addressFrom, addressTo, amount, side, Adecimal, Bdecimal } = token
        // amount = amount - ((amount / 100) * 0.2)
        amount > 0 ? await PanCakeRouterContract
            .getAmountsOut(Moralis.Units.Token(amount, Adecimal), [addressFrom, addressTo])
            .then(async final => {
                let outputs = parseFloat(Moralis.Units.FromWei(String(final[1]), Bdecimal)).toFixed(5)
                side == 'pay' && setDataData(data => data = { ...data, amountTo: outputs })
                side == 'receive' && setDataData(data => data = { ...data, amountFrom: outputs })
                side == undefined && setDataData(data => data = { ...data })
                setDataData(data => data = { ...data, thereIsPriceNow: true })
                setDataData(data => data = { ...data, priceImpact: 'checking impact...' })
                getPriceImpact(side == 'pay' ? amount : outputs, { token0: addressFrom, token1: addressTo })
            })
            .catch(error => console.info(error))
            :
            setDataData(data => data = {
                ...data, amountTo: '0.00', amountFrom: '0.00', thereIsPriceNow: false
            })
    }

    function getOutPutAmountFromPayingTokens(amountfrom) {
        let value = amountfrom.target.value
        setDataData(data => data = { ...data, amountFrom: value })
        if (value > 0) {
            getAmountOutput({
                addressTo: dashData.receive.address,
                addressFrom: dashData.pay.address, amount: value, side: 'pay',
                Bdecimal: dashData.receive.decimals, Adecimal: dashData.pay.decimals
            })
        }
    }

    function getInPutAmountFromReceivedTokens(amountto) {
        let value = amountto.target.value
        setDataData(data => data = { ...data, amountTo: value })
        if (value > 0) {
            getAmountOutput({
                addressFrom: dashData.receive.address,
                addressTo: dashData.pay.address, amount: value, side: 'receive',
                Adecimal: dashData.receive.decimals, Bdecimal: dashData.pay.decimals,
            })
        }
    }

    async function handleAccountbalance() {
        if (window.address != undefined) {
            // if (dashData.tokenFrom.tags == 'native' || dashData.tokenTo.tags == 'native'){}
            const tokenFromContract = new ethers.Contract(dashData.pay.address, AbiFunctions, window.provider)
            const tokenToContract = new ethers.Contract(dashData.receive.address, AbiFunctions, window.provider)
            await Promise.all([
                tokenFromContract.balanceOf(window.address),
                tokenToContract.balanceOf(window.address)
            ])
                .then(response => {
                    setDataData(data => data = {
                        ...data,
                        tokenFrombalance: Moralis.Units.FromWei(response[0], dashData.pay.decimals),
                        tokenToBalance: Moralis.Units.FromWei(response[1], dashData.receive.decimals)
                    })
                })
        }
    }

    handleAccountbalance()

    async function getPriceImpact(amount, path) {
        const { PanCakeRouterContract } = window
        const { token0, token1 } = path
        let done = true
        if (done == true) {
            done = false
            await PanCakeRouterContract.factory()
                .then(async response => {
                    const factory = new ethers.Contract(String(response), AbiFunctions, window.Sign)
                    await factory.getPair(token0, token1)
                        .then(async response => {
                            const priceImpact = await PooReserves({
                                poolAddress: String(response),
                                amountPayin: amount,
                            });
                            setDataData(data => data = { ...data, priceImpact: priceImpact })
                        })
                        .catch(error => console.info(error))
                })
                .catch(error => console.info(error))
            done = true
        }
    }


    const TradeSumarry = (
        <div className="details-content">
            {/* <div className="card-content flex-nowrap">
                            <i className="qrt-status qrt-status-current"></i>
                            Calculating...
                        </div> */}

            <div className="card-content flex-nowrap space-between">
                <span className="font-13">Price impact</span>
                <span className={`font-13`}
                    style={{ color: dashData.priceImpact < 1 ? 'green' : dashData.priceImpact < 5.001 && dashData.priceImpact > 3.05 ? 'gold' : dashData.priceImpact > 5.0011 ? 'red' : 'grey' }}
                >{dashData.priceImpact} %</span>
            </div>

            <div className="card-content flex-nowrap space-between">
                <span className="font-13">Minimum Received</span>
                <span className="font-13">{dashData.amountTo}&nbsp;&bull;&nbsp;{dashData.receive.symbol}</span>
            </div>

            <div className="card-content flex-nowrap space-between">
                <span className="font-13 ">Route</span>
                <span className="font-13 flex-nowrap uppercase">
                    <span className="font-13">{dashData.pay.symbol}</span>
                    <GetIcon icon={'directionhorizontal'} />
                    <span className="font-13">{dashData.receive.symbol}</span>
                </span>
            </div>

        </div>
    )


    return (
        <motion.div
            initial={{ x: -100 }}
            animate={{ x: 0 }}
            exit={{ x: 100 }}
            className={`swap-tokens-wrapper`}
        >
            <TokensList
                params={TokenSideParams}
            />

            <h4 className="h4-headline flex-nowrap space-between">
                <span>Swap</span>
                <GetIcon icon={'settings'} trigger={() => ShowDexSettings(false)} classname={'spinner'} />
            </h4>

            <div className="swap-tokens-fields">

                <div className="swap-input-main flex-column">
                    <div className="card-content flex-nowrap space-between" style={{ marginBottom: '.6rem' }}>
                        <span className="side-name">Pay</span>
                        <span className="side-name">{dashData.pay.symbol}: {dashData.tokenFrombalance}</span>
                    </div>

                    <motion.div
                        className="swap-input-inner flex-nowrap space-between"
                        whileHover={{ scale: 1.01, }}
                        whileTap={{ scale: 0.95 }}
                    >

                        <motion.input
                            contentEditable
                            step={0.1}
                            className="swap-int-input"
                            placeholder={dashData.floatPlaceHolder}
                            onInput={getOutPutAmountFromPayingTokens}
                            pattern='[0.0-9]+'
                            type={'number'}
                            max={'99999999999'}
                            min={1}
                            value={dashData.amountFrom}
                        />

                        <div
                            onClick={() => showTokensListSide('pay', true)}
                            className="swap-selector flex-nowrap no-gray">
                            <GetIcon icon={dashData.pay.logoURI} />
                            <span className="selected-side">
                                {dashData.pay.symbol ? dashData.pay.symbol : "Select"}
                            </span>
                        </div>
                    </motion.div>
                </div>

                <div className="swap-inputs">
                    <GetIcon icon={'change'} />
                </div>

                <div className="swap-input-main flex-column">
                    <div className="card-content flex-nowrap space-between" style={{ marginBottom: '.6rem' }}>
                        <span className="side-name">Receive</span>
                        <span className="side-name">{dashData.receive.symbol}: {dashData.tokenToBalance}</span>
                    </div>

                    <motion.div
                        className="swap-input-inner flex-nowrap space-between"
                        whileHover={{ scale: 1.01, }}
                        whileTap={{ scale: 0.95 }}
                    >
                        <input
                            contentEditable
                            step={0.1}
                            className="swap-int-input"
                            placeholder={dashData.floatPlaceHolder}
                            onInput={getInPutAmountFromReceivedTokens}
                            pattern='[0.0-9]+'
                            type={'number'}
                            max={'99999999999'}
                            min={0.005}
                            value={dashData.amountTo}
                        />

                        <div
                            className="swap-selector flex-nowrap no-gray"
                            onClick={() => showTokensListSide('receive', true)} >
                            <GetIcon icon={dashData.receive.logoURI} />
                            <span className="selected-side">
                                {dashData.receive.symbol ? dashData.receive.symbol : 'Select'}
                            </span>
                        </div>
                    </motion.div>
                </div>

                {/* <details>
                    <summary className="flex-nowrap space-between">
                        <h3 className="h3-headline summary-notation flex-nowrap">
                            <GetIcon icon={'information'} classname='icon-size-21' />
                            &nbsp;
                            {dashData.pay.symbol} 1 = {dashData.receive.symbol} {dashData.tokenFromRate}
                        </h3>

                        <h3 className="h3-headline summary-notation flex-nowrap">
                            <GetIcon icon={'gasstation'} classname='icon-size-21' />
                            &nbsp;
                            ($----)
                        </h3>
                    </summary>
                </details> */}

                <div className="button-input-wrapper " style={{ minWidth: '100%' }}>
                    <button
                        className={
                            `primary-btn ${dashData.priceImpact > 7 ? 'iserror'
                                : dashData.priceImpact < 5.001 && dashData.priceImpact > 3.05 ? 'inactive'
                                    : isAuthenticated && !isCorrectNetwork ? 'iserror'
                                        : isLoading ? 'inactive' : 'notif'} `
                        }
                        disabled={
                            dashData.priceImpact > 7.0011
                                || dashData.claimButtonDisabled
                                || isLoading
                                || isFetching
                                || isAuthenticating
                                ? true
                                : false
                        }
                        style={{ minWidth: '100%' }}
                        onClick={isAuthenticated && !isCorrectNetwork ? switchNetwork : isAuthenticated ? SwapTokens : login} >
                        <span>{
                            dashData.priceImpact > 7.0011 ? 'Price Impact Too High' :
                                isAuthenticated && isCorrectNetwork ?
                                    `Swap ${dashData.pay.symbol + ' for ' + dashData.receive.symbol}` : isAuthenticating ? 'Authenticating...' : !isCorrectNetwork ? 'Switch to ' + window.chainName + ' Network' : 'Connect Wallet'}</span>
                    </button>
                </div>

                {dashData.thereIsPriceNow && wWidth >= 500 ? TradeSumarry : TradeSumarry}

            </div>
            <Modal
                params={ModalParams}
            />
        </motion.div>

    )
}


export default DexInterface