import { GetIcon } from "../icons/ExportIcon"
import { useEffect, useState } from 'react'
import { numFormatter } from "../reuseables/Numbers"
import { BigNumber } from "ethers"
import { formatUnits } from "ethers/lib/utils"

function Header({ params }) {

    const {
        login, logout, address,
        isAuthenticated, isAuthenticating, logo,
        showNav, shown, dataLoading,
        ArceusContract, isCorrectNetwork, switchNetwork,
        addTokenToWallet, marketPrice } = params

    const [wWidth, setwWidth] = useState(window.innerWidth)
    useEffect(() => window.addEventListener('resize', () => setwWidth(window.innerWidth)))

    const [myBalance, setMybalance] = useState(dataLoading)
    useEffect(() => {
        let doneFetch = true
        setInterval(async () => {
            if (isAuthenticated && window.address != undefined && doneFetch == true) {
                doneFetch = false
                const getMyBalance = await ArceusContract.balanceOf(window.address)
                setMybalance(bal => bal = numFormatter(formatUnits(BigNumber.from(getMyBalance), '5')))
                doneFetch = true
            }
        }, 1000);
    }, [isAuthenticated])

    const logoImage = (
        <img
            onClick={() => window.location.href = '/'}
            src={logo}
            className={'logo-image not-on-mobile'} />
    )

    return (
        <header className="header-main">
            <div className='flex-nowrap bar-toggle' >
                {shown && wWidth >= 800 ? logoImage : wWidth <= 800 ? logoImage : ''}
                {/* <h3 className='h3-headline sm-headline'>{appname}</h3> */}
                {shown && wWidth >= 800 ? <span>&nbsp;&nbsp;</span> : wWidth <= 800 ? <span>&nbsp;&nbsp;</span> : ''}

                <div className='toggle-nav flex-nowrap'>
                    <GetIcon icon={'menubar'} trigger={showNav} classname='toggle-menu' />
                    {/* <GetIcon icon={'ethereum'} classname='' />
                    <span className='font-16'>$2,342</span> */}
                </div>
            </div>

            <div className='user-actions'>

                <div className='t-price has-dropdown'>

                    <GetIcon icon={'arccoin'} />
                    <span className='font-16'>$ {marketPrice()}</span>

                    <div className='is-dropdown'>
                        <div onClick={addTokenToWallet} className='flex dropdown-list'>
                            <span className='dropdown-list-text'>Add ARC to wallet</span>
                        </div>
                    </div>

                </div>

                {
                    !isCorrectNetwork && <div className='t-price iserror' onClick={switchNetwork}>

                        <span className='font-13'>Wrong Network</span>

                    </div>
                }


                <div className={`t-price ${isAuthenticated && 'has-dropdown'}`} onClick={!isAuthenticated ? login : undefined}>

                    <GetIcon icon={isAuthenticated ? 'wallet' : isAuthenticating ? 'spinner' : 'connected'} classname={isAuthenticating ? 'spinner' : null} />
                    {!isAuthenticating && <span className='font-13'>{address && isAuthenticated ? address.slice(0, 4) + '****' + address.slice(-4) : 'Connect Wallet'}</span>}

                    <div className='is-dropdown'>
                        <div onClick={isAuthenticated ? logout : isAuthenticating ? null : login} className='flex dropdown-list'>
                            {/* <GetIcon icon={isAuthenticated ? 'logout' : isAuthenticating ? 'spinner' : 'login'} classname={isAuthenticating ? 'spinner' : null} /> */}
                            <span className='dropdown-list-text'>{isAuthenticated ? 'Disconnect' : isAuthenticating ? 'Authenticating.' : 'Login'}</span>
                        </div>

                        <div className='flex  dropdown-list'>
                            <span className='dropdown-list-text'>ARC {myBalance}</span>
                        </div>
                    </div>

                </div>

                {/* <GetIcon icon={'guest_male'} classname='' /> */}
            </div>
        </header>
    )
}
export default Header