import { Link } from "react-router-dom"
import { GetIcon } from "../icons/ExportIcon"
import { useState, useEffect } from 'react'
import { ProSidebar, Menu, MenuItem, SidebarHeader, SubMenu, SidebarFooter, SidebarContent } from 'react-pro-sidebar';
import SocialLinks from '../reuseables/SocialLinks'

function SideBarNavigation({ params }) {

    const { tokensymbol } = params
    const { login, isAuthenticated, isAuthenticating, logo, shown, showNav, motion } = params
    // const [mToggle, setMtoggle] = useState(false)
    const [wWidth, setwWidth] = useState(window.innerWidth)
    useEffect(() => window.addEventListener('resize', () => setwWidth(window.innerWidth)))

    function HideMenu(event) {
        // Array.from(document.querySelectorAll('.nav-link')).map(
        //     navLink => {
        //         if (event.target == navLink) {
        //             navLink.classList.add('active  disabled-link')
        //         } else { navLink.classList.remove('active disabled-link') }
        //     }
        // )
        shown === true && wWidth <= 975 && showNav()
    }

    return (
        <ProSidebar
            className="navigation-main"
            toggled={shown}
            collapsedWidth={0.001}
            collapsed={shown && wWidth >= 975 && true}
            breakPoint={'xs | sm | md | lg'}
            onToggle={(false)}
            style={{ width: shown && wWidth <= 500 ? '100vw' : '0' }}
        >

            <SidebarHeader>
                <div className='logo  no-gray' onClick={() => window.location.href = '/'}>
                    {/* <img src={logo} className={'logo-image'} /> */}
                    <GetIcon icon={'arcfavi'} classname={'logo-image'} />
                    <h3 className='h3-headline  site-name'>{'Arceus Pro'}</h3> {/*sm-headline*/}
                </div>
            </SidebarHeader>

            <SidebarContent className="side-bar-inner">
                <Menu className="nav-main" >
                    <MenuItem className="nav-link-wrap ">
                        <Link to={'/@/dashboard'} className={`nav-link`} onClick={HideMenu}>
                            <GetIcon icon={'dashboard'} />
                            <span className="link-name">Dashboard</span>
                        </Link>
                    </MenuItem>

                    <MenuItem className="nav-link-wrap ">
                        <Link to={'/@/account'} className={`nav-link`} onClick={HideMenu}>
                            <GetIcon icon={'guest_male'} />
                            <span className="link-name">Account</span>
                        </Link>
                    </MenuItem>
                    {/* <SubMenu title="COMING SOON" style={{ padding: '0 1rem' }} > */}
                    {/* <MenuItem className="nav-link-wrap ">
                        <Link to={'/@/swap/bnb/arc'} className={`nav-link`} onClick={HideMenu}>
                            <GetIcon icon={'guest_male'} />
                            <span className="link-name">Dex</span>
                        </Link>
                    </MenuItem> */}
                    {/* <span className="nav-divider">Earn With Arceus</span> */}

                    <MenuItem className="nav-link-wrap">
                        <Link to={'/@/arbitrage'} className={`nav-link`} onClick={HideMenu}>
                            <GetIcon icon={'guest_male'} />
                            <span className="link-name">Arbitrage</span>
                        </Link>
                    </MenuItem>
                    <MenuItem className="nav-link-wrap ">
                        <Link to={'/@/account'} className={`nav-link`} onClick={HideMenu}>
                            <GetIcon icon={'guest_male'} />
                            <span className="link-name">Hodlers</span>
                        </Link>
                    </MenuItem>
                    {/* </SubMenu> */}

                    <MenuItem className="nav-link-wrap ">
                        <Link to={'/@/swap/bnb/arc'} className={`nav-link`} onClick={HideMenu}>
                            <GetIcon icon={'exchange'} />
                            <span className="link-name">Swap</span>
                        </Link>
                    </MenuItem>

                    <MenuItem className="nav-link-wrap ">
                        <Link to={'/@/calculator'} className={`nav-link`} onClick={HideMenu}>
                            <GetIcon icon={'estimate'} />
                            <span className="link-name">Calculate ROI</span>
                        </Link>
                    </MenuItem>

                    <MenuItem className="nav-link-wrap ">
                        <Link to={'/@/token'} className={`nav-link`} onClick={HideMenu}>
                            <GetIcon icon={'analytics'} />
                            <span className="link-name">Token</span>
                        </Link>
                    </MenuItem>

                    <MenuItem className="nav-link-wrap ">
                        <Link to={'/@/claim'} className={`nav-link`} onClick={HideMenu}>
                            <GetIcon icon={'receivecash'} />
                            <span className="link-name">Claim Rewards</span>
                            {
                                isAuthenticated ? <span className="notification-count">---</span>
                                    : isAuthenticating ? <span className="notification-count">loading...</span>
                                        : <span className="notification-count">notConnected</span>
                            }
                        </Link>
                    </MenuItem>

                    <MenuItem className="nav-link-wrap ">
                        <Link to={'//'} className={`nav-link`} onClick={HideMenu}>
                            <GetIcon icon={'documents'} />
                            <span className="link-name">Documentation</span>
                        </Link>
                    </MenuItem>
                </Menu>
            </SidebarContent>


            {shown && wWidth <= 975 && <GetIcon icon={'close'} trigger={showNav} classname='close-menu-mobile' />}

            <SidebarFooter>
                <SocialLinks />
            </SidebarFooter>

        </ProSidebar>
    )
}

export default SideBarNavigation