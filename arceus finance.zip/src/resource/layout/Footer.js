function Footer({ params }) {
    const { motion } = params
    return (
        <motion.footer
            initial={{ opacity: 0, y: -100 }}
            animate={{ opacity: 1, y: 0 }}
            className="footer-main">
            <div className="footer-links-wrap">
                <a href="">doc</a>
                <a href="">website</a>
                <a href="">coming soon</a>
            </div>
            <div className="font-13">
                {new Date().getFullYear()} @ArcuesProtocol
            </div>
        </motion.footer>
    )
}

export default Footer