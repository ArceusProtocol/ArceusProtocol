import { GetIcon } from "../icons/ExportIcon"

function E404(params) {
    const url = window.location.pathname
    return (
        <section className="section">
            <div className='center-element padding-1rem flex-wrap contents-center' >
                <h1 className='h1-headline center-text w-full'>Page Not Found</h1>
                <GetIcon icon={'brokenlink'} classname='broken-link' />
                <span className="font-16 center-text w-full" style={{ 'color': 'red' }}>{url} 
                <i style={{ 'color': 'white' }}> is broken.</i></span>
            </div>
        </section>
    )
}

export default E404