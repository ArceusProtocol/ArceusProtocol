function ShowMessage({ params }) {

    const { show, data } = params

    async function launchMetamask() {

    }

    if (show === true)
        return (
            <div className="app-meage-wrapper" style={{ 'background': data.type == 'success' && 'green' }}>
                <div className="flex-nowrap">
                    <div>{data.content}</div>
                    {
                        typeof data.solution == 'function' && data.solution != 'function' ?
                            <i onClick={data.solution}>&nbsp; &nbsp; || &nbsp; &nbsp; Click Here.</i>
                            : data.solution != null && <a target={'_blank'} href={data.solution}>&nbsp; &nbsp; || &nbsp; &nbsp; Link</a>
                    }
                </div>
            </div>
        )
}

export default ShowMessage