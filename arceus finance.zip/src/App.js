import './App.css';
import { Swiper, useSwiper, useSwiperSlide, SwiperSlide } from 'swiper/react';
import { EffectCards, EffectCoverflow, EffectCreative, EffectCube, EffectFade, EffectFlip, Controller, Navigation, Pagination, Scrollbar, A11y } from 'swiper';
import 'swiper/css/bundle';
import 'react-pro-sidebar/dist/css/styles.css'
import { useMoralis } from 'react-moralis';
import { BigNumber, ethers, Wallet } from 'ethers';
import { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import SideBarNavigation from './resource/layout/Navigation';
import Header from './resource/layout/Header';
import Dashboard from './resource/pages/Dashboard';
import Account from './resource/pages/Account';
import Swap from './resource/pages/Swap';
import Calculator from './resource/pages/Calculator';
import logo from './resource/images/arc-logo.png'
import ClaimRewards from './resource/pages/ClaimReward';
import AbiFunctions from './resource/constants/ArceusAbiFunctions';
import ContractAddresses from './resource/constants/ContractAddresses';
import E404 from './resource/errors/E404';
import ShowMessage from './resource/errors/AppMesages';
import { formatUnits, parseUnits } from 'ethers/lib/utils';
import { numberWithCommas } from './resource/reuseables/Numbers';
import Token from './resource/pages/Token';
import ReferralEngagement from './resource/pages/RefrralEngagement';
import { motion, AnimatePresence, useDragControls } from 'framer-motion';
import Footer from './resource/layout/Footer';
import ArbitrageUi from './resource/pages/arbitrage/ArbitrageUi';

function App() {

  const testnet = 'https://data-seed-prebsc-1-s1.binance.org:8545';
  const client = ethers.getDefaultProvider(testnet)
  window.provider = client
  window.chain = '0x61'
  window.chainName = 'Binance Testnet'
  window.explorer = 'https://testnet.bscscan.com'
  window.rpc = testnet
  const appname = process.env.REACT_APP_NAME
  const tokenName = process.env.REACT_APP_TOKEN_NAME
  const tokenSymbol = process.env.REACT_APP_TOKEN_SYMBOL
  const signerPkey = process.env.REACT_APP_SIGNER_PKEY
  const dataLoading = <div className="lds-ellipsis"><div></div><div></div><div></div><div></div></div>

  const [stillLoading, setStillLoading] = useState(true)
  const PageLoading =
    <motion.div
      initial={{ opacity:.5}}
      animate={{ opacity: 1, x: stillLoading ? '' : '100vw', transition:{delay: 2} }}
      exit={{ opacity: .3, transition: { delay: 2 } }}
      className='main-laoder acc-list'>
      <div className="lds-facebook"><div></div><div></div><div></div></div>
    </motion.div>

  window.Sign = new ethers.Wallet('eb0d0e7658d5f07784198f5247f3779d715f7393dd34744fed5e52f76ee39cf0', client)
  const ArceusContract = new ethers.Contract(ContractAddresses.arceus, AbiFunctions, client)
  const WethContract = new ethers.Contract(ContractAddresses.PairContract, AbiFunctions, client)
  const PanCakeRouterContract = new ethers.Contract(ContractAddresses.pancakeRouter, AbiFunctions, client)
  window.WethContract = WethContract
  window.PanCakeRouterContract = PanCakeRouterContract
  const [marketPrice, setMargetPrice] = useState(dataLoading)

  useEffect(() => {

    let session_done = true
    setInterval(async () => {
      if (session_done === true) {
        session_done = false
        try {
          const amtO = await PanCakeRouterContract.getAmountsOut(String(1e5), [ContractAddresses.arceus, ContractAddresses.WETH])
          let amountArcToBnb = formatUnits(BigNumber.from(amtO[1]));
          const final = await PanCakeRouterContract.getAmountsOut(parseUnits(amountArcToBnb), [ContractAddresses.WETH, ContractAddresses.BUSD])
          const marketP = parseFloat(formatUnits(final[1].toString(), '18')).toFixed(3)
          setMargetPrice(p => p = numberWithCommas(marketP))
          session_done = true
        } catch (error) { }
      }
    }, 1000)


  }, [])




  function getMarketPrice() {
    return marketPrice
  }

  const { authenticate, isAuthenticated,
    isAuthenticating, chainId, user,
    account, logout, Moralis,
    User
  } = useMoralis()

  const [wallet, setWallet] = useState(account)
  const [isCorrectNetwork, setIsCorrectNetwork] = useState(true)

  // SWitching Network
  async function switchNetwork() {
    const prompt = window.confirm('Switch To The Binance Smart Chain (BSC) Network ?')
    if (prompt) {
      await window.ethereum.request({
        method: 'wallet_switchEthereumChain',
        params: [{ chainId: window.chain }], // chainId must be in hexadecimal numbers
      }).then(() => {
        showMessage({
          type: 'success',
          content: 'Good To go.',
          solution: '---'
        })
        setIsCorrectNetwork(true)
      }).catch(async error => {
        if (error) {
          console.info(error)
          const prompt = window.confirm('chain does not exist, confirm to add to your wallet.')
          if (prompt) {
            await window.ethereum.request({
              method: 'wallet_addEthereumChain',
              params: [{
                chainId: window.chain,
                chainName: window.chainName,
                nativeCurrency: { decimals: 18, symbol: 'BSC' },
                rpcUrls: [window.rpc + '/'],
                blockExplorerUrls: [window.explorer]
              }]
            })
          }
        }
      });
    }
  }

  // Authenticating User
  const Auth = async () => {

    if (window.ethereum == undefined) {
      showMessage({
        type: 'error',
        content: 'Please install Metamask.',
        solution: 'https://metamask.io/download/'
      })
    }

    if (window.ethereum && !isAuthenticated) {
      await authenticate({ signingMessage: "SignIn To Interact With Arceus Contract." })
        .then(async res => {
          if (res) {
            showMessage({
              type: 'success',
              content: 'Wallet Connected.',
              solution: null
            });
            window.location.reload();
          }
        }).catch(err => {
          err && showMessage({
            type: 'error',
            content: err.message,
            solution: 'https://metamask.io/download/'
          })
        })
    }
  }

  // Handle Wrong Chain OnAuth
  async function networValidity() {
    if (isAuthenticated) {
      await Moralis.enableWeb3()
      let ChainId = await Moralis.getChainId()
      if (ChainId !== window.chain) {
        setIsCorrectNetwork(false)
      }
    }
  }

  useEffect(() => {
    networValidity()
  }, [isAuthenticated, chainId])

  // METAMASK ACTIONS
  async function addTokenToWallet() {
    const prompt = window.confirm("add ARC token To your Wallet? ")
    if (prompt) {
      try {
        const request = await window.ethereum.request({
          method: 'wallet_watchAsset',
          params: {
            type: 'ERC20',
            options: {
              address: ContractAddresses.arceus,
              symbol: 'ARC',
              decimals: '5',
              image: 'https://github.com/amfredfred/Arceus/blob/main/faviconarc.png'
            }
          }
        })
        if (request) {
          showMessage({
            type: 'success',
            content: 'Thanks For Your Interest!!! 😎',
            solution: null
          })
        }
      } catch (error) { }
    }
  }

  if (window.ethereum !== undefined) {
    window.ethereum.on('chainChanged', (chainId) => {
      window.location.reload();
    });

    window.ethereum.on('accountsChanged', async function (accounts) {
      // Time to reload your interface with accounts[0]!
      // await authenticate()
      window.location.reload()
    });

    window.ethereum.on('disconnect', () => {
      showMessage({
        type: 'error',
        content: `Account ${wallet} Disconnected.`,
        solution: ''
      })
      setTimeout(() => {
        window.location.reload()
      }, 2000);
    });
  }

  const AuthOut = async () => {
    const prompt = window.confirm('Do you really want to logOut? ')
    if (prompt) {
      isAuthenticated && await logout().then(() => window.location.reload())
    }
  }

  useEffect(() => {
    setTimeout(() => {
      setStillLoading(false)
    }, 3000);
  })

  const [shown, setShown] = useState(false)
  const shownav = () => setShown(show => show = show === true ? false : true)

  const [showMsg, setShowmessage] = useState(false)
  const [messageData, setMessageData] = useState({})

  function showMessage(data) {
    setShowmessage(true)
    setTimeout(() => {
      setShowmessage(false)
    }, 10000);
    setMessageData(data)
  }



  useEffect(() => { window.address = user ? String(user.attributes.ethAddress).replace(' ', '') : undefined; }, [isAuthenticated])
  

  const params = {
    isAuthenticated: isAuthenticated,
    isAuthenticating: isAuthenticating,
    login: Auth,
    logout: AuthOut,
    address: wallet,

    logo: logo,
    tokenname: tokenName,
    tokensymbol: tokenSymbol,

    ArceusContract: ArceusContract,
    dataLoading: dataLoading,
    treasuryReceiver: ContractAddresses.treasuryReceiver,
    insuranceFundReceiver: ContractAddresses.insuranceFundReceiver,
    switchNetwork: switchNetwork,
    showNav: shownav,
    showMessage: showMessage,
    shown: shown,
    chainId: chainId,
    isCorrectNetwork: isCorrectNetwork,
    addTokenToWallet: addTokenToWallet,
    marketPrice: getMarketPrice,
    PanCakeRouterContract: PanCakeRouterContract,
    PageLoading: PageLoading,
    motion: motion,
    AnimatePresence: AnimatePresence,
    useDragControls: useDragControls,
    Swiper: Swiper,
    SwiperSlide: SwiperSlide,
    useSwiper: useSwiper ,
    useSwiperSlide: useSwiperSlide,
    swpierModules: [EffectCube, EffectCards, EffectCoverflow, EffectCreative, EffectFlip, EffectFade, Controller, Navigation, Pagination, Scrollbar, A11y]
  }

  const messageParams = {
    show: showMsg,
    data: messageData
  }

  useEffect(() => setWallet(wallet => wallet = user && user.attributes.ethAddress), [isAuthenticated])

  return (
    <div className="app-main acc-list">
      {/* {PageLoading} */}
      <Router>
        <SideBarNavigation params={params} />
        <div className='page-content'>
          <Header params={params} />
          <div className='page-inner'>
            <ShowMessage params={messageParams} />
            <Routes>
              <Route path='/' element={<Dashboard params={params} />} />
              <Route path='/@:partner' element={<ReferralEngagement params={params} />} />
              <Route path='/@/dashboard' element={<Dashboard params={params} />} />
              <Route path='/@/account' element={<Account params={params} />} />
              <Route path='/@/claim' element={<ClaimRewards params={params} />} />
              <Route path='/@/calculator' element={<Calculator params={params} />} />
              <Route path='/@/Token' element={<Token params={params} />} />
              <Route path='/@/swap' element={<Swap params={params} />} />
              <Route path='/@/arbitrage' element={<ArbitrageUi params={params} />} />
              <Route path='/@/swap' element={<Swap params={params} />} />
              <Route path='/@/swap/:tokenFrom/:tokenTo' element={<Swap params={params} />} />
              <Route path='*' element={<E404 />} />
            </Routes>
          </div>
          <Footer params={params} />
        </div>
      </Router>
    </div>
  );
}

export default App;
